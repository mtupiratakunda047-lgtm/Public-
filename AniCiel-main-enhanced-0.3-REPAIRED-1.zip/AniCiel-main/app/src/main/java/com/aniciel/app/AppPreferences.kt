package com.aniciel.app

import android.content.Context

class AppPreferences(context: Context) {
    private val prefs = context.getSharedPreferences("aniciel_preferences", Context.MODE_PRIVATE)

    var profileName: String
        get() = prefs.getString("profile_name", "Default") ?: "Default"
        set(value) = prefs.edit().putString("profile_name", value.trim().ifBlank { "Default" }).apply()

    var compactGrid: Boolean
        get() = prefs.getBoolean("compact_grid", false)
        set(value) = prefs.edit().putBoolean("compact_grid", value).apply()

    var adultEnabled: Boolean
        get() = prefs.getBoolean("adult_enabled", false)
        set(value) = prefs.edit().putBoolean("adult_enabled", value).apply()

    fun sourceEnabled(id: String, defaultValue: Boolean = true): Boolean =
        prefs.getBoolean("source_$id", defaultValue)

    fun setSourceEnabled(id: String, enabled: Boolean) {
        prefs.edit().putBoolean("source_$id", enabled).apply()
    }
}
