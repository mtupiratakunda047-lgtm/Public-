package com.aniciel.app

import android.content.Context
import android.os.Environment
import androidx.core.content.edit
import java.io.File

data class StorageVolume(
    val index: Int,
    val label: String,
    val rootPath: String,
    val isRemovable: Boolean
)

/**
 * Where downloaded episodes get written. Backed by getExternalFilesDirs,
 * which returns one app-private directory per storage volume (index 0 is
 * always the primary/phone storage; further entries are removable SD
 * cards, when present) -- these are real filesystem paths our Rust
 * downloader can write to directly, unlike a SAF-picked content:// URI.
 */
object DownloadSettings {
    private const val PREFS = "download_settings"
    private const val KEY_VOLUME_INDEX = "volume_index"
    private const val KEY_SUBDIR = "subdir"
    private const val DEFAULT_SUBDIR = "downloads"

    fun listVolumes(context: Context): List<StorageVolume> {
        val dirs = context.getExternalFilesDirs(null)
        return dirs.mapIndexedNotNull { index, dir ->
            if (dir == null) return@mapIndexedNotNull null
            val removable = try {
                Environment.isExternalStorageRemovable(dir)
            } catch (_: Exception) {
                index != 0
            }
            StorageVolume(
                index = index,
                label = if (index == 0) "Phone storage" else "SD card${if (dirs.size > 2) " ${index}" else ""}",
                rootPath = dir.absolutePath,
                isRemovable = removable
            )
        }
    }

    fun subdirectory(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_SUBDIR, DEFAULT_SUBDIR) ?: DEFAULT_SUBDIR

    fun selectedVolumeIndex(context: Context): Int =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_VOLUME_INDEX, 0)

    fun save(context: Context, volumeIndex: Int, subdirectory: String) {
        val safeSubdir = subdirectory.trim().ifBlank { DEFAULT_SUBDIR }
            .replace(Regex("[^A-Za-z0-9._\\- /]"), "_")
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit {
            putInt(KEY_VOLUME_INDEX, volumeIndex)
            putString(KEY_SUBDIR, safeSubdir)
        }
    }

    /** Resolves the current choice to a real, writable directory, falling back to phone storage. */
    fun resolvedDir(context: Context): File {
        val volumes = listVolumes(context)
        val chosenIndex = selectedVolumeIndex(context)
        val volume = volumes.firstOrNull { it.index == chosenIndex } ?: volumes.firstOrNull()
        val root = volume?.rootPath ?: context.filesDir.absolutePath
        return File(root, subdirectory(context))
    }
}
