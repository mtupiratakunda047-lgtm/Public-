package com.aniciel.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val CielBlue = Color(0xFF29B6F6)
val CielBlueBright = Color(0xFF5DD6FF)
val AppBlack = Color(0xFF000000)
val SurfaceBlack = Color(0xFF121316)
val CardBlack = Color(0xFF1A1C20)

private val AniCielColors = darkColorScheme(
    primary = CielBlue,
    onPrimary = Color.Black,
    secondary = CielBlueBright,
    background = AppBlack,
    onBackground = Color.White,
    surface = SurfaceBlack,
    onSurface = Color.White,
    surfaceVariant = CardBlack,
    onSurfaceVariant = Color(0xFFB0BEC5)
)

@Composable
fun AniCielTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = AniCielColors, content = content)
}
