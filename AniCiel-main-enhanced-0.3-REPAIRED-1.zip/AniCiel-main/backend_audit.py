#!/usr/bin/env python3
from pathlib import Path
import re, sys

root = Path(__file__).resolve().parent
errors = []

def read(rel):
    return (root / rel).read_text(encoding="utf-8", errors="ignore")

downloader = read("app/src/main/java/com/aniciel/app/Downloader.kt")
service = read("app/src/main/java/com/aniciel/app/DownloadService.kt")
gradle = read("app/build.gradle")
workflow = read(".github/workflows/build.yml")

if "DashDownloader.download" not in downloader:
    errors.append("Downloader.kt is not wired to DashDownloader")
if "android.R.drawable.stat_sys_download" not in service:
    errors.append("DownloadService.kt is not using the Android system download icon")
if "media3-exoplayer-dash" not in gradle:
    errors.append("Media3 DASH player dependency is missing")
if "platforms;android-34" not in workflow:
    errors.append("GitHub Actions does not explicitly install Android API 34")
if not (root / "gradlew").exists():
    errors.append("Termux Gradle bootstrap script is missing")

registry = read("app/src/main/java/com/aniciel/app/SourceRegistry.kt")
if "SourceState.REFERENCE" not in registry:
    errors.append("Reference-only source state is missing")

if errors:
    print("FAIL")
    for e in errors:
        print(" -", e)
    sys.exit(1)

print("PASS")
print(" - DASH downloader wired")
print(" - Download notification icon uses android.R")
print(" - Media3 DASH player dependency present")
print(" - CI installs Android API 34")
print(" - Termux Gradle bootstrap present")
print(" - Reference-only sources remain explicitly separated")
