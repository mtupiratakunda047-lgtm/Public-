@echo off
setlocal
where gradle >nul 2>nul
if %ERRORLEVEL%==0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
echo Gradle is not installed. Use Termux/Android with ./gradlew, or install Gradle on Windows.
exit /b 127
