# AniCiel source integration

The app now has a central source registry and Source Center UI. It distinguishes:

- **Ready**: wired into the current Rust/Android engine.
- **Optional**: an existing adapter is present but should be health-gated before enabling.
- **Reference**: useful source/extraction code was found in the supplied projects but it is not falsely presented as an Android-ready adapter.
- **Offline / disabled**: known network-local or currently disabled providers.

The registry includes Movies, Anime, Manga and Adult categories. Authentication is deliberately not included.

The existing Android downloader remains the runtime media downloader. HLS/DASH support is handled natively; the supplied Python/Playwright projects are not embedded as a desktop runtime.
