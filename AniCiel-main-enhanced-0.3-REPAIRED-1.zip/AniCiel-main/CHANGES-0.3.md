# AniCiel 0.3 integration changes

- Added four-section bottom navigation: Movies, Anime, Manga, Adult.
- Added central Source Center with source categories, capabilities, and integration states.
- Added local profile preferences without authentication.
- Added compact-grid preference.
- Added separated Adult section and source inventory.
- Added featured media row on browse screens.
- Added source-center access from the main toolbar.
- Added third-party license notices and source audit documentation.
- Added Rust engine test execution to GitHub Actions before Android cross-compilation.
- Removed machine-specific `.ssh`, `.lesshst`, and `.gitconfig` artifacts from the distributable project.
- Kept Termux configuration and GitHub Actions because they are relevant to the requested deployment workflow.
- Kept the existing native Rust engine, downloader, HLS/DASH support, favorites, downloads, player, and existing providers.

Important: reference source entries are catalogued but are not falsely marked as working Android adapters. They require an Android-compatible adapter and validation before activation.


## Backend repair pass — 2026-10-02

- Added an Android-native MPEG-DASH/MPD downloader with SegmentTemplate/SegmentTimeline and SegmentList support.
- DASH now downloads selected clear (non-DRM) audio/video representations and remuxes them with `MediaMuxer`.
- DASH segment progress is checkpointed so pause/cancel followed by resume does not restart completed segments.
- DRM-protected and dynamic/live MPDs are rejected with explicit errors instead of being saved as XML/text.
- Kept HLS and ordinary resumable-file paths separate from DASH.
- Confirmed `DownloadService.kt` uses the Android system download icon namespace (`android.R.drawable...`).
- Added a Termux-friendly Gradle bootstrap script and wrapper properties.
- Kept reference-only source entries explicitly marked as `REFERENCE`; they are not presented as operational Android adapters.
