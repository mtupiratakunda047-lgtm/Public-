//! AniDB.app anime source (https://anidb.app).
//!
//! Unlike the other providers this one is a "sidecar": it isn't a
//! `ProviderKind` variant (adding one would mean editing every exhaustive
//! `match` across the TUI, which the Android app never runs but still has
//! to compile). Instead it returns `serde_json::Value`s already in the
//! shapes the Kotlin layer parses, and `ffi.rs` routes the provider string
//! "anidbapp" to it directly.
//!
//! How the site works:
//!   * search:   GET /browse?q=<query>            -> HTML grid of anime cards
//!   * details:  GET /anime/anime-<id>            -> HTML page (title, genres...)
//!   * episodes: GET /api/frontend/anime/<id>/episodes        -> JSON
//!   * streams:  GET /api/frontend/episode/<eid>/languages    -> JSON with an
//!     embed page per language; that page contains one or more .m3u8 URLs
//!     which are HLS playlists (a master playlist lists one variant per
//!     resolution).
//!
//! Streams are HLS: they play in ExoPlayer (with the HLS module) and are
//! downloaded by `hls_download` (unencrypted, non-live playlists only).

use reqwest::Client;
use scraper::{ElementRef, Html, Selector};
use serde_json::{Value, json};
use std::time::Duration;

pub const PROVIDER_ID: &str = "anidbapp";
const DEFAULT_BASE_URL: &str = "https://anidb.app";
const USER_AGENT: &str = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

/// Titles carrying any of these genres are refused at the details step, so
/// they can never be opened, played or downloaded through the app.
const BLOCKED_GENRES: [&str; 2] = ["hentai", "erotica"];

#[derive(Debug, Clone)]
pub struct AniDbAppClient {
    client: Client,
    base_url: String,
}

impl Default for AniDbAppClient {
    fn default() -> Self {
        Self::new()
    }
}

#[derive(Debug, Clone)]
struct EpisodeEntry {
    id: String,
    number: f64,
}

#[derive(Debug, Default)]
struct ParsedInfo {
    title: Option<String>,
    image: Option<String>,
    year: Option<i64>,
    genres: Vec<String>,
    synopsis: Option<String>,
}

impl AniDbAppClient {
    pub fn new() -> Self {
        let client = crate::net::http_client_builder()
            .timeout(Duration::from_secs(15))
            .user_agent(USER_AGENT)
            .build()
            .unwrap_or_default();
        Self {
            client,
            base_url: DEFAULT_BASE_URL.to_string(),
        }
    }

    async fn get_text(&self, url: &str) -> Result<String, String> {
        let res = self
            .client
            .get(url)
            .send()
            .await
            .map_err(|e| e.to_string())?;
        let status = res.status();
        if !status.is_success() {
            return Err(format!("HTTP {status} from {url}"));
        }
        res.text().await.map_err(|e| e.to_string())
    }

    async fn get_json(&self, url: &str) -> Result<Value, String> {
        let text = self.get_text(url).await?;
        serde_json::from_str(&text).map_err(|e| format!("bad JSON from {url}: {e}"))
    }

    /// First page of results for `query`, as CatalogItem-shaped JSON.
    pub async fn search(&self, query: &str) -> Result<Vec<Value>, String> {
        let mut url = url::Url::parse(&format!("{}/browse", self.base_url))
            .map_err(|e| e.to_string())?;
        url.query_pairs_mut().append_pair("q", query);
        let html = self.get_text(url.as_str()).await?;
        Ok(parse_search(&html, &self.base_url))
    }

    async fn fetch_episodes(&self, id: &str) -> Result<Vec<EpisodeEntry>, String> {
        let url = format!("{}/api/frontend/anime/{}/episodes", self.base_url, id);
        let res = self.get_json(&url).await?;
        let arr = res
            .get("episodes")
            .and_then(|v| v.as_array())
            .ok_or_else(|| "episode list missing from response".to_string())?;

        let mut out: Vec<EpisodeEntry> = arr
            .iter()
            .filter_map(|e| {
                let number_value = e.get("number")?;
                let number = number_value
                    .as_f64()
                    .or_else(|| number_value.as_str().and_then(|s| s.trim().parse().ok()))?;
                let id = match e.get("id")? {
                    Value::String(s) => s.clone(),
                    other => other.to_string(),
                };
                Some(EpisodeEntry { id, number })
            })
            .collect();
        out.sort_by(|a, b| {
            a.number
                .partial_cmp(&b.number)
                .unwrap_or(std::cmp::Ordering::Equal)
        });
        Ok(out)
    }

    /// MediaDetails-shaped JSON. Everything is one season; fractional
    /// episode numbers (5.5 recaps and the like) are left out because the
    /// UI addresses episodes by whole numbers.
    pub async fn details(&self, id: &str) -> Result<Value, String> {
        let page_url = format!("{}/anime/anime-{}", self.base_url, id);
        let html = self.get_text(&page_url).await?;
        let info = parse_details(&html, &self.base_url);

        if info
            .genres
            .iter()
            .any(|g| BLOCKED_GENRES.contains(&g.to_ascii_lowercase().as_str()))
        {
            return Err("This title is not available in AniCiel".to_string());
        }

        let episodes = self.fetch_episodes(id).await.unwrap_or_default();
        let mut numbers: Vec<i64> = episodes
            .iter()
            .filter(|e| e.number >= 1.0 && e.number.fract() == 0.0)
            .map(|e| e.number as i64)
            .collect();
        numbers.dedup();

        let seasons = if numbers.is_empty() {
            json!([])
        } else {
            let eps: Vec<Value> = numbers
                .iter()
                .map(|n| json!({ "season": 1, "number": n, "title": Value::Null }))
                .collect();
            json!([{ "number": 1, "episodes": eps }])
        };

        Ok(json!({
            "id": { "provider": PROVIDER_ID, "value": id },
            "title": info.title.unwrap_or_else(|| "Unknown".to_string()),
            "media_type": "series",
            "year": info.year.map(|y| y.to_string()),
            "description": info.synopsis,
            "tagline": Value::Null,
            "imdb_rating": Value::Null,
            "director": Value::Null,
            "stars": Value::Null,
            "duration": Value::Null,
            "poster_url": info.image,
            "genres": info.genres,
            "seasons": seasons,
        }))
    }

    /// Release-shaped JSON for one episode: one entry per (language,
    /// resolution), each with a single HLS mirror.
    pub async fn releases(&self, id: &str, episode: usize) -> Result<Vec<Value>, String> {
        let episodes = self.fetch_episodes(id).await?;
        let entry = episodes
            .iter()
            .find(|e| e.number == episode as f64)
            .ok_or_else(|| format!("episode {episode} not found"))?;

        let url = format!(
            "{}/api/frontend/episode/{}/languages",
            self.base_url, entry.id
        );
        let res = self.get_json(&url).await?;
        let languages = res
            .get("languages")
            .and_then(|v| v.as_array())
            .cloned()
            .unwrap_or_default();

        let mut releases: Vec<Value> = Vec::new();
        for lang in languages {
            let code = lang.get("code").and_then(|c| c.as_str()).unwrap_or("");
            let label = match code {
                "jpn" => "Sub",
                "eng" => "Dub",
                _ => continue,
            };
            let embed = match lang.get("embed_url").and_then(|u| u.as_str()) {
                Some(u) => absolutize(&self.base_url, u),
                None => continue,
            };
            let embed_page = match self.get_text(&embed).await {
                Ok(t) => t,
                Err(_) => continue,
            };

            for stream_url in extract_m3u8_urls(&embed_page) {
                for (height, variant_url) in self.expand_playlist(&stream_url).await {
                    let quality = if height > 0 {
                        format!("{height}p · {label}")
                    } else {
                        format!("Auto · {label}")
                    };
                    releases.push(json!({
                        "provider": PROVIDER_ID,
                        "filename": format!("episode-{episode}"),
                        "quality": quality,
                        "codec": Value::Null,
                        "language": code,
                        "size_bytes": Value::Null,
                        "season": 1,
                        "episode": episode,
                        "mirrors": [{
                            "label": "HLS",
                            "resolver_url": variant_url,
                            "headers": [["User-Agent", USER_AGENT]],
                            "direct_file": false,
                        }],
                        "resource_id": Value::Null,
                    }));
                }
            }
        }

        // Highest resolution first within the whole list.
        releases.sort_by_key(|r| {
            let q = r.get("quality").and_then(|q| q.as_str()).unwrap_or("");
            std::cmp::Reverse(
                q.split('p')
                    .next()
                    .and_then(|n| n.trim().parse::<u32>().ok())
                    .unwrap_or(0),
            )
        });
        Ok(releases)
    }

    /// Fetches an .m3u8. A master playlist expands to its variants
    /// (height, absolute URL); a plain media playlist -- or one we can't
    /// fetch to inspect -- comes back as a single entry with height 0
    /// ("Auto") and is left for the player to sort out.
    async fn expand_playlist(&self, url: &str) -> Vec<(u32, String)> {
        let text = match self.get_text(url).await {
            Ok(t) => t,
            Err(_) => return vec![(0, url.to_string())],
        };
        let variants = parse_master_playlist(&text, url);
        if variants.is_empty() {
            vec![(0, url.to_string())]
        } else {
            variants
        }
    }
}

// ---------------------------------------------------------------------
// Pure parsing helpers (no network, unit-testable)
// ---------------------------------------------------------------------

fn collapse_ws(s: &str) -> String {
    s.split_whitespace().collect::<Vec<_>>().join(" ")
}

fn absolutize(base: &str, src: &str) -> String {
    match url::Url::parse(base).and_then(|b| b.join(src)) {
        Ok(u) => u.to_string(),
        Err(_) => src.to_string(),
    }
}

fn element_text(el: &ElementRef) -> String {
    collapse_ws(&el.text().collect::<String>())
}

fn parse_search(html: &str, base: &str) -> Vec<Value> {
    let doc = Html::parse_document(html);
    let card_sel = Selector::parse("div.anime-grid a.anime-card").expect("valid selector");
    let p_sel = Selector::parse("p").expect("valid selector");
    let img_sel = Selector::parse("img").expect("valid selector");

    let mut out = Vec::new();
    for card in doc.select(&card_sel) {
        let href = match card.value().attr("href") {
            Some(h) => h,
            None => continue,
        };
        let id = match href.trim_end_matches('/').rsplit('-').next() {
            Some(s) if !s.is_empty() => s.to_string(),
            _ => continue,
        };
        let title = card
            .select(&p_sel)
            .next()
            .map(|p| element_text(&p))
            .unwrap_or_default();
        if title.is_empty() {
            continue;
        }
        let poster = card
            .select(&img_sel)
            .next()
            .and_then(|img| {
                img.value()
                    .attr("src")
                    .or_else(|| img.value().attr("data-src"))
            })
            .map(|s| absolutize(base, s));

        out.push(json!({
            "id": { "provider": PROVIDER_ID, "value": id },
            "title": title,
            "media_type": "series",
            "year": Value::Null,
            "poster_url": poster,
            "season_count": Value::Null,
        }));
    }
    out
}

fn parse_details(html: &str, base: &str) -> ParsedInfo {
    let doc = Html::parse_document(html);
    let h1_sel = Selector::parse("h1.leading-tight").expect("valid selector");
    let img_sel = Selector::parse("img.object-cover").expect("valid selector");
    let a_sel = Selector::parse("a").expect("valid selector");
    let div_sel = Selector::parse("div").expect("valid selector");
    let p_sel = Selector::parse("p").expect("valid selector");

    let title = doc
        .select(&h1_sel)
        .next()
        .map(|e| element_text(&e))
        .filter(|s| !s.is_empty());

    let image = doc
        .select(&img_sel)
        .next()
        .and_then(|e| e.value().attr("src"))
        .map(|s| absolutize(base, s));

    let year = doc
        .select(&a_sel)
        .filter_map(|a| a.value().attr("href").map(|h| (a, h)))
        .find(|(_, h)| h.contains("/browse?season=") && h.contains("&year="))
        .and_then(|(a, _)| {
            element_text(&a)
                .split_whitespace()
                .last()
                .and_then(|t| t.parse::<i64>().ok())
        });

    // The genre chips live in the last "flex flex-wrap gap-1.5 mb-4" div.
    let genres = doc
        .select(&div_sel)
        .filter(|d| d.value().attr("class") == Some("flex flex-wrap gap-1.5 mb-4"))
        .last()
        .map(|container| {
            container
                .select(&a_sel)
                .filter(|a| {
                    a.value()
                        .attr("href")
                        .is_some_and(|h| h.contains("/genres/") || h.contains("/themes/"))
                })
                .map(|a| element_text(&a))
                .filter(|s| !s.is_empty())
                .collect::<Vec<String>>()
        })
        .unwrap_or_default();

    let synopsis = doc
        .select(&p_sel)
        .find(|p| p.value().attr("class") == Some("text-sm text-faint leading-relaxed"))
        .map(|p| element_text(&p))
        .filter(|s| !s.is_empty());

    ParsedInfo {
        title,
        image,
        year,
        genres,
        synopsis,
    }
}

/// Pulls stream playlist URLs out of an embed page's script, i.e. the
/// quoted value in `file: "...m3u8"` or `source = "...m3u8"`.
fn extract_m3u8_urls(text: &str) -> Vec<String> {
    let mut urls: Vec<String> = Vec::new();
    let mut search_from = 0;

    while let Some(rel) = text[search_from..].find(".m3u8") {
        let pos = search_from + rel;
        search_from = pos + ".m3u8".len();

        // Opening quote before the URL...
        let start = match text[..pos].rfind(|c: char| c == '"' || c == '\'') {
            Some(s) => s,
            None => continue,
        };
        let quote = match text[start..].chars().next() {
            Some(q) => q,
            None => continue,
        };
        // ...and the matching closing quote after it.
        let end = match text[pos..].find(quote) {
            Some(e) => pos + e,
            None => continue,
        };

        // Only accept it when it's the value of a file/source assignment.
        let before = text[..start].trim_end();
        let assigned = (before.ends_with(':') || before.ends_with('='))
            && {
                let word = before[..before.len() - 1].trim_end().to_ascii_lowercase();
                word.ends_with("file") || word.ends_with("source")
            };
        if !assigned {
            continue;
        }

        let candidate = text[start + 1..end].replace("\\/", "/");
        if candidate.chars().any(|c| c.is_whitespace() || c == '<' || c == '>') {
            continue;
        }
        if !(candidate.starts_with("http") || candidate.starts_with('/')) {
            continue;
        }
        if !urls.contains(&candidate) {
            urls.push(candidate);
        }
    }
    urls
}

/// Variants of an HLS master playlist as (height, absolute url), tallest
/// first, one per distinct height. Empty for a plain media playlist.
fn parse_master_playlist(text: &str, playlist_url: &str) -> Vec<(u32, String)> {
    let mut variants: Vec<(u32, String)> = Vec::new();
    let mut expecting_uri = false;
    let mut pending_height: u32 = 0;

    for line in text.lines() {
        let line = line.trim();
        if let Some(attrs) = line.strip_prefix("#EXT-X-STREAM-INF:") {
            expecting_uri = true;
            pending_height = attrs
                .split(',')
                .find_map(|kv| kv.trim().strip_prefix("RESOLUTION="))
                .and_then(|res| res.split('x').nth(1))
                .and_then(|h| h.trim().parse::<u32>().ok())
                .unwrap_or(0);
        } else if expecting_uri && !line.is_empty() && !line.starts_with('#') {
            variants.push((pending_height, absolutize(playlist_url, line)));
            expecting_uri = false;
            pending_height = 0;
        }
    }

    variants.sort_by(|a, b| b.0.cmp(&a.0));
    variants.dedup_by_key(|v| v.0);
    variants
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn extracts_quoted_m3u8_assignments() {
        let page = r#"<script>var player = { file: "https://cdn.example/a/master.m3u8?t=1", x: 1 };
            const source = 'https://cdn.example/b.m3u8';
            var other = "https://cdn.example/not-assigned.m3u8";</script>"#;
        let urls = extract_m3u8_urls(page);
        assert_eq!(
            urls,
            vec![
                "https://cdn.example/a/master.m3u8?t=1".to_string(),
                "https://cdn.example/b.m3u8".to_string()
            ]
        );
    }

    #[test]
    fn parses_master_playlist_variants() {
        let playlist = "#EXTM3U\n\
            #EXT-X-STREAM-INF:BANDWIDTH=800000,RESOLUTION=1280x720,CODECS=\"avc1.4d401f,mp4a.40.2\"\n\
            720/index.m3u8\n\
            #EXT-X-STREAM-INF:BANDWIDTH=2000000,RESOLUTION=1920x1080\n\
            1080/index.m3u8\n";
        let v = parse_master_playlist(playlist, "https://cdn.example/a/master.m3u8");
        assert_eq!(
            v,
            vec![
                (1080, "https://cdn.example/a/1080/index.m3u8".to_string()),
                (720, "https://cdn.example/a/720/index.m3u8".to_string()),
            ]
        );
    }

    #[test]
    fn media_playlist_has_no_variants() {
        let playlist = "#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXTINF:10,\nseg0.ts\n";
        assert!(parse_master_playlist(playlist, "https://cdn.example/x.m3u8").is_empty());
    }

    #[test]
    fn parses_search_cards() {
        let html = r#"<div class="anime-grid">
            <a class="anime-card" href="/anime/one-piece-21"><img src="/img/21.jpg"><p> One  Piece </p></a>
            <a class="anime-card" href="/anime/naruto-20"><p>Naruto</p></a></div>"#;
        let items = parse_search(html, "https://anidb.app");
        assert_eq!(items.len(), 2);
        assert_eq!(items[0]["id"]["value"], "21");
        assert_eq!(items[0]["title"], "One Piece");
        assert_eq!(items[0]["poster_url"], "https://anidb.app/img/21.jpg");
        assert_eq!(items[1]["poster_url"], Value::Null);
    }
}
