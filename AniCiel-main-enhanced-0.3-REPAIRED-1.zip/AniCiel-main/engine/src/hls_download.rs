//! Downloads an HLS (.m3u8) stream into a single file by fetching every
//! segment in order and appending it. MPEG-TS segments concatenate into a
//! playable .ts; fMP4 streams (an EXT-X-MAP init segment plus .m4s
//! segments) concatenate into a fragmented .mp4. Either way, players sniff
//! the content, so the file extension the caller picked doesn't matter.
//!
//! Deliberately unsupported, with a clear error instead of a broken file:
//!   * encrypted streams (EXT-X-KEY other than METHOD=NONE)
//!   * byte-range playlists (EXT-X-BYTERANGE)
//!   * live playlists (no EXT-X-ENDLIST)

use reqwest::Client;
use std::io::Write;
use std::path::Path;
use std::sync::Arc;
use std::sync::atomic::{AtomicBool, Ordering};
use std::time::{Duration, Instant};

pub enum HlsOutcome {
    Completed { bytes: u64 },
    Cancelled { bytes: u64 },
}

pub struct HlsProgress {
    pub downloaded: u64,
    /// Extrapolated from the segments fetched so far.
    pub estimated_total: u64,
    pub bytes_per_second: f64,
}

#[derive(Debug, PartialEq)]
struct MediaPlaylist {
    init_segment: Option<String>,
    segments: Vec<String>,
}

fn join(base: &str, target: &str) -> String {
    match url::Url::parse(base).and_then(|b| b.join(target)) {
        Ok(u) => u.to_string(),
        Err(_) => target.to_string(),
    }
}

/// Splits `KEY=VALUE,KEY2="VALUE,WITH,COMMAS"` style attribute lists.
fn parse_attrs(attrs: &str) -> Vec<(String, String)> {
    let mut parts: Vec<String> = Vec::new();
    let mut current = String::new();
    let mut in_quotes = false;
    for c in attrs.chars() {
        match c {
            '"' => {
                in_quotes = !in_quotes;
                current.push(c);
            }
            ',' if !in_quotes => parts.push(std::mem::take(&mut current)),
            _ => current.push(c),
        }
    }
    if !current.is_empty() {
        parts.push(current);
    }

    let mut out = Vec::new();
    for part in parts {
        if let Some((k, v)) = part.split_once('=') {
            out.push((
                k.trim().to_ascii_uppercase(),
                v.trim().trim_matches('"').to_string(),
            ));
        }
    }
    out
}

/// The tallest (then highest-bandwidth) variant of a master playlist.
fn pick_best_variant(text: &str, base: &str) -> Option<String> {
    let mut best: Option<(u64, String)> = None;
    let mut pending: Option<u64> = None;

    for line in text.lines() {
        let line = line.trim();
        if let Some(rest) = line.strip_prefix("#EXT-X-STREAM-INF:") {
            let attrs = parse_attrs(rest);
            let bandwidth = attrs
                .iter()
                .find(|(k, _)| k == "BANDWIDTH")
                .and_then(|(_, v)| v.parse::<u64>().ok())
                .unwrap_or(0);
            let height = attrs
                .iter()
                .find(|(k, _)| k == "RESOLUTION")
                .and_then(|(_, v)| v.split('x').nth(1))
                .and_then(|h| h.trim().parse::<u64>().ok())
                .unwrap_or(0);
            pending = Some(height * 1_000_000_000 + bandwidth);
        } else if let Some(score) = pending {
            if !line.is_empty() && !line.starts_with('#') {
                let candidate = join(base, line);
                if best.as_ref().map_or(true, |(s, _)| score > *s) {
                    best = Some((score, candidate));
                }
                pending = None;
            }
        }
    }
    best.map(|(_, u)| u)
}

fn parse_media_playlist(text: &str, base: &str) -> Result<MediaPlaylist, String> {
    let mut init_segment = None;
    let mut segments = Vec::new();
    let mut ended = false;

    for line in text.lines() {
        let line = line.trim();
        if line.is_empty() {
            continue;
        }
        if let Some(rest) = line.strip_prefix("#EXT-X-KEY:") {
            let method = parse_attrs(rest)
                .into_iter()
                .find(|(k, _)| k == "METHOD")
                .map(|(_, v)| v.to_ascii_uppercase())
                .unwrap_or_else(|| "NONE".to_string());
            if method != "NONE" {
                return Err(
                    "This stream is encrypted (AES-128), which isn't supported for downloads yet"
                        .to_string(),
                );
            }
        } else if let Some(rest) = line.strip_prefix("#EXT-X-MAP:") {
            if let Some((_, uri)) = parse_attrs(rest).into_iter().find(|(k, _)| k == "URI") {
                init_segment = Some(join(base, &uri));
            }
        } else if line.starts_with("#EXT-X-BYTERANGE") {
            return Err("Byte-range playlists aren't supported for downloads yet".to_string());
        } else if line.starts_with("#EXT-X-ENDLIST") {
            ended = true;
        } else if !line.starts_with('#') {
            segments.push(join(base, line));
        }
    }

    if !ended {
        return Err("This looks like a live stream, which can't be downloaded".to_string());
    }
    if segments.is_empty() {
        return Err("The playlist has no video segments".to_string());
    }
    Ok(MediaPlaylist {
        init_segment,
        segments,
    })
}

async fn fetch_text(client: &Client, url: &str) -> Result<String, String> {
    let res = client.get(url).send().await.map_err(|e| e.to_string())?;
    if !res.status().is_success() {
        return Err(format!("HTTP {} fetching playlist", res.status()));
    }
    res.text().await.map_err(|e| e.to_string())
}

async fn fetch_bytes(client: &Client, url: &str) -> Result<Vec<u8>, String> {
    let mut last_error = String::new();
    for attempt in 0..3u64 {
        match client.get(url).send().await {
            Ok(res) if res.status().is_success() => match res.bytes().await {
                Ok(bytes) => return Ok(bytes.to_vec()),
                Err(e) => last_error = e.to_string(),
            },
            Ok(res) => last_error = format!("HTTP {}", res.status()),
            Err(e) => last_error = e.to_string(),
        }
        tokio::time::sleep(Duration::from_millis(400 * (attempt + 1))).await;
    }
    Err(format!("A video segment kept failing ({last_error})"))
}

pub async fn download_hls<F>(
    client: &Client,
    playlist_url: &str,
    destination: &Path,
    cancel: Arc<AtomicBool>,
    mut report: F,
) -> Result<HlsOutcome, String>
where
    F: FnMut(HlsProgress),
{
    let text = fetch_text(client, playlist_url).await?;
    let (media_url, media_text) = if text.contains("#EXT-X-STREAM-INF") {
        let variant = pick_best_variant(&text, playlist_url)
            .ok_or_else(|| "No playable variant found in the playlist".to_string())?;
        let variant_text = fetch_text(client, &variant).await?;
        (variant, variant_text)
    } else {
        (playlist_url.to_string(), text)
    };

    let playlist = parse_media_playlist(&media_text, &media_url)?;

    if let Some(parent) = destination.parent() {
        std::fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    }
    let mut file = std::fs::File::create(destination)
        .map_err(|e| format!("Couldn't create the download file: {e}"))?;

    let mut urls: Vec<String> = Vec::new();
    if let Some(init) = &playlist.init_segment {
        urls.push(init.clone());
    }
    urls.extend(playlist.segments.iter().cloned());
    let total_segments = urls.len().max(1) as u64;

    let started = Instant::now();
    let mut downloaded: u64 = 0;

    for (index, url) in urls.iter().enumerate() {
        if cancel.load(Ordering::Relaxed) {
            drop(file);
            let _ = std::fs::remove_file(destination);
            return Ok(HlsOutcome::Cancelled { bytes: downloaded });
        }

        let bytes = match fetch_bytes(client, url).await {
            Ok(b) => b,
            Err(e) => {
                drop(file);
                let _ = std::fs::remove_file(destination);
                return Err(e);
            }
        };
        file.write_all(&bytes)
            .map_err(|e| format!("Writing the download failed: {e}"))?;
        downloaded += bytes.len() as u64;

        let done = (index + 1) as u64;
        let seconds = started.elapsed().as_secs_f64().max(0.001);
        report(HlsProgress {
            downloaded,
            estimated_total: downloaded * total_segments / done,
            bytes_per_second: downloaded as f64 / seconds,
        });
    }

    file.flush()
        .map_err(|e| format!("Writing the download failed: {e}"))?;
    Ok(HlsOutcome::Completed { bytes: downloaded })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn picks_tallest_variant() {
        let master = "#EXTM3U\n\
            #EXT-X-STREAM-INF:BANDWIDTH=800000,RESOLUTION=1280x720\n720/i.m3u8\n\
            #EXT-X-STREAM-INF:BANDWIDTH=2000000,RESOLUTION=1920x1080\n1080/i.m3u8\n";
        assert_eq!(
            pick_best_variant(master, "https://cdn.example/a/master.m3u8"),
            Some("https://cdn.example/a/1080/i.m3u8".to_string())
        );
    }

    #[test]
    fn parses_plain_media_playlist() {
        let text = "#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXTINF:10,\nseg0.ts\n#EXTINF:10,\nseg1.ts\n#EXT-X-ENDLIST\n";
        let p = parse_media_playlist(text, "https://cdn.example/v/index.m3u8").unwrap();
        assert_eq!(p.init_segment, None);
        assert_eq!(
            p.segments,
            vec![
                "https://cdn.example/v/seg0.ts".to_string(),
                "https://cdn.example/v/seg1.ts".to_string()
            ]
        );
    }

    #[test]
    fn reads_fmp4_init_segment() {
        let text = "#EXTM3U\n#EXT-X-MAP:URI=\"init.mp4\"\n#EXTINF:6,\na.m4s\n#EXT-X-ENDLIST\n";
        let p = parse_media_playlist(text, "https://cdn.example/v/index.m3u8").unwrap();
        assert_eq!(p.init_segment, Some("https://cdn.example/v/init.mp4".to_string()));
        assert_eq!(p.segments.len(), 1);
    }

    #[test]
    fn rejects_encrypted_live_and_byterange() {
        let enc = "#EXTM3U\n#EXT-X-KEY:METHOD=AES-128,URI=\"k.bin\"\n#EXTINF:6,\na.ts\n#EXT-X-ENDLIST\n";
        assert!(parse_media_playlist(enc, "https://x/i.m3u8").is_err());
        let live = "#EXTM3U\n#EXTINF:6,\na.ts\n";
        assert!(parse_media_playlist(live, "https://x/i.m3u8").is_err());
        let br = "#EXTM3U\n#EXT-X-BYTERANGE:100@0\n#EXTINF:6,\na.ts\n#EXT-X-ENDLIST\n";
        assert!(parse_media_playlist(br, "https://x/i.m3u8").is_err());
    }

    #[test]
    fn quoted_attribute_commas_survive() {
        let attrs = parse_attrs("METHOD=AES-128,URI=\"https://k/a,b\",IV=0x01");
        assert_eq!(attrs[1], ("URI".to_string(), "https://k/a,b".to_string()));
    }
}
