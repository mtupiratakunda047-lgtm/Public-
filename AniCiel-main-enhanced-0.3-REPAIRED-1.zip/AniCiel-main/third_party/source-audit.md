# Source audit from supplied archives

## Current Android/Rust-ready sources
- MovieBox
- AniDB.app metadata sidecar

## Existing optional Rust adapters retained
- 4KHDHub
- Dramachi
- CircleFTP (BDIX)
- DhakaFlix (BDIX)
- Addons

These are not forced on at startup when the current engine marks them unavailable.

## Anime-Sama/Nakanime extractor inventory
- Ansembed
- Embed4me
- Filemoon
- Luluvdo
- Movearnpre
- OneUpload
- Sendvid
- Sibnet
- Uqload
- Vidmoly
- Vidzy
- Voe
- HLS/M3U8 pipeline
- TS segment parser/repair
- FFmpeg conversion
- fallback download and file verification

## Zine manga/manhwa source inventory
- MangaDex
- FanFox
- KunManga
- Mangak
- TopManhua
- WeebCentral
- AsuraScans
- ManhuaPlus
- ProjectSuki

## Zine adult source inventory
- Hanime
- Hanime Red
- Hentaicity
- HentaiHaven
- HentaiHaven Co
- HentaiMama
- HStream
- OHentai
- Oppai Stream
- Pornhub
- Hentai18
- Hentai20
- Manga18FX
- ManhwaUS
- OmegaScans
- Oppai Stream Toon
- ASMHentai
- NHenTai

The Android app keeps these categories separated. The registry does not claim a reference adapter is currently operational; a source must have an Android-compatible adapter and pass validation before being marked Ready.
