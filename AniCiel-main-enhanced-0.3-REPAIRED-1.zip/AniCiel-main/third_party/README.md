# Third-party integration notes

AniCiel uses selected architecture and source information from the supplied projects. The Android app does not blindly embed their desktop/Python runtimes.

- **Anikku**: Apache License 2.0. UI/source-management ideas were adapted; retain the original license when distributing any copied code.
- **Anime-Sama-Nakanime-Downloader**: GPL-3.0. Its HLS/FFmpeg/download architecture is referenced; do not copy GPL implementation into a differently licensed module without complying with GPL-3.0.
- **Zine Scraper**: CC BY-NC-SA 4.0. The supplied archive is retained as a reference for source/extraction architecture. Adapted material must comply with the license and any additional permission supplied by its copyright holder.

MovieBox/other supplied projects are used as references only unless their individual licensing permits direct redistribution.
