# AniCiel Termux / GitHub APK build

## Local Termux

From the project root:

```sh
pkg update
pkg install git openjdk-17 unzip curl
chmod +x ./gradlew
./gradlew assembleDebug --no-daemon
```

If your Termux repository provides Gradle, `pkg install gradle` is also supported; the
included `gradlew` bootstrap will use an installed `gradle` first.

The debug APK is produced at:

`app/build/outputs/apk/debug/app-debug.apk`

## Rust engine

The Android engine is a Rust `cdylib`. For a full local native build you also need the
Android NDK and Rust Android targets. GitHub Actions installs the NDK and builds both
`arm64-v8a` and `armeabi-v7a` before assembling the APK.

## GitHub Actions

Push the repository to GitHub. `.github/workflows/build.yml` runs Rust tests, cross-compiles
the engine, assembles a debug APK, and uploads it as the `app-debug` artifact.

## Download architecture

- Direct files use the resumable HTTP downloader.
- HLS `.m3u8` uses the HLS segment downloader.
- DASH `.mpd` uses `DashDownloader.kt`.
- Clear DASH audio/video tracks are remuxed to MP4 with Android `MediaMuxer`.
- DRM-protected DASH is intentionally rejected; the app does not bypass DRM.
