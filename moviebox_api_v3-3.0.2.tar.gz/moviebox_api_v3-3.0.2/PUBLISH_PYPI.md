# Publier `moviebox_api_v3` sur PyPI

Ce projet est nettoyé pour PyPI : il ne contient plus `app.py`, `requirements.txt`, fichiers serveur ou fichiers d'hébergement. Les dépendances sont dans `pyproject.toml`.

## 1. Préparer le dépôt GitHub

```bash
git init
git add .
git commit -m "Initial release moviebox_api_v3"
git branch -M main
git remote add origin https://github.com/VOTRE_USERNAME/moviebox_api_v3.git
git push -u origin main
```

Dans `pyproject.toml`, remplacez :

```text
https://github.com/your-username/moviebox_api_v3
```

par votre vraie URL GitHub.

## 2. Créer un compte PyPI et TestPyPI

Créez un compte sur :

- PyPI : https://pypi.org/
- TestPyPI : https://test.pypi.org/

Puis créez un token API dans votre compte.

## 3. Installer les outils de publication

```bash
python -m pip install --upgrade pip
python -m pip install --upgrade build twine
```

## 4. Nettoyer les anciennes builds

```bash
rm -rf dist build *.egg-info
```

Sous Windows PowerShell :

```powershell
Remove-Item -Recurse -Force dist, build, *.egg-info -ErrorAction SilentlyContinue
```

## 5. Construire le package

```bash
python -m build
```

Vous devez obtenir :

```text
dist/moviebox_api_v3-3.0.1.tar.gz
dist/moviebox_api_v3-3.0.1-py3-none-any.whl
```

## 6. Vérifier le package

```bash
python -m twine check dist/*
```

## 7. Publier d'abord sur TestPyPI

```bash
python -m twine upload --repository testpypi dist/*
```

Identifiants :

```text
username: __token__
password: pypi-votre_token_testpypi
```

## 8. Tester l'installation depuis TestPyPI

Créez un nouvel environnement virtuel, puis :

```bash
python -m pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple moviebox_api_v3
python -c "from moviebox_api_v3.v3.core import Search; print('OK')"
```

## 9. Publier sur PyPI officiel

Quand tout est OK :

```bash
python -m twine upload dist/*
```

Identifiants :

```text
username: __token__
password: pypi-votre_token_pypi
```

## 10. Installer depuis PyPI officiel

```bash
pip install moviebox_api_v3
```

Test :

```bash
python -c "import moviebox_api_v3; print(moviebox_api_v3.__version__)"
```

## 11. Publier une nouvelle version

PyPI n'accepte jamais deux uploads avec le même numéro de version.

Pour publier une correction :

1. Changez la version dans `pyproject.toml`, par exemple `3.0.1` vers `3.0.2`.
2. Changez aussi le fallback dans `moviebox_api_v3/__init__.py` si besoin.
3. Rebuild :

```bash
rm -rf dist build *.egg-info
python -m build
python -m twine check dist/*
python -m twine upload dist/*
```
