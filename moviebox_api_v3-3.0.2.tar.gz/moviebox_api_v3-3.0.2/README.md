# moviebox_api_v3

`moviebox_api_v3` est une bibliothèque Python asynchrone pour interagir avec l'API MovieBox v3.

> Projet non officiel. Ce package n'est pas affilié à MovieBox. Utilisez-le uniquement dans le respect des lois applicables et des conditions d'utilisation des services concernés.

## Installation

```bash
pip install moviebox_api_v3
```

Avec les outils CLI :

```bash
pip install "moviebox_api_v3[cli]"
```

## Exemple rapide

```python
import asyncio

from moviebox_api_v3.v3.constants import SubjectType
from moviebox_api_v3.v3.core import Search
from moviebox_api_v3.v3.http_client import MovieBoxHttpClient


async def main():
    async with MovieBoxHttpClient(timeout=8) as client:
        api = Search(
            client_session=client,
            query="avatar",
            subject_type=SubjectType.ALL,
            page=1,
            per_page=10,
        )
        data = await api.get_content()
        print(data)


if __name__ == "__main__":
    asyncio.run(main())
```

## Configuration région/langue

La bibliothèque lit plusieurs variables d'environnement avant l'import des constantes :

```bash
export MOVIEBOX_ACCEPT_LANGUAGE="fr-MG,fr-FR;q=0.95,fr;q=0.9,en-US;q=0.6,en;q=0.5"
export MOVIEBOX_ACCEPT_COUNTRY="MG"
export MOVIEBOX_ACCEPT_TIMEZONE="Indian/Antananarivo"
export MOVIEBOX_REGION="MG"
export MOVIEBOX_SYSTEM_LANGUAGE="fr"
export MOVIEBOX_LOCALE_TAG="fr_MG"
export MOVIEBOX_PREFERRED_DUB="French"
```

## CLI

Après installation avec l'extra `cli` :

```bash
moviebox-api-v3 --help
moviebox-v3 --help
```

## Publication PyPI

Les étapes complètes sont dans [`PUBLISH_PYPI.md`](PUBLISH_PYPI.md).

Résumé :

```bash
python -m pip install --upgrade build twine
python -m build
python -m twine check dist/*
python -m twine upload --repository testpypi dist/*
python -m twine upload dist/*
```

## Structure

```text
moviebox_api_v3/
├── v1/
├── v2/
└── v3/
```

La partie recommandée pour les nouveaux projets est `moviebox_api_v3.v3`.


## Android / Pydroid compatibility

The base package does not require `pydantic`, so installation works on platforms where `pydantic-core` wheels are unavailable.

For typed Pydantic models on desktop/server environments, install:

```bash
pip install moviebox_api_v3[models]
```

On Android/Pydroid, prefer the raw dictionary methods such as `get_content()` instead of `get_content_model()`.
