package com.aniciel.app

import org.json.JSONArray
import org.json.JSONObject

data class CatalogItem(
    val id: String,
    val provider: String,
    val title: String,
    val mediaType: String,
    val year: String?,
    val posterUrl: String?,
    val seasonCount: Int?
)

data class EpisodeInfo(val season: Int, val number: Int, val title: String?, val overview: String? = null)
data class SeasonInfo(val number: Int, val episodes: List<EpisodeInfo>)

data class MediaDetails(
    val id: String,
    val provider: String,
    val title: String,
    val mediaType: String,
    val year: String?,
    val description: String?,
    val tagline: String?,
    val imdbRating: String?,
    val director: String?,
    val stars: String?,
    val duration: String?,
    val posterUrl: String?,
    val genres: List<String>,
    val seasons: List<SeasonInfo>
)

data class MirrorInfo(
    val label: String,
    val url: String,
    val headers: List<Pair<String, String>>,
    val directFile: Boolean
) {
    /** HLS (.m3u8) playlist. The engine downloads these segment by segment (unencrypted, non-live only). */
    val isHls: Boolean get() = url.contains(".m3u8", ignoreCase = true)
}

data class ReleaseInfo(
    val quality: String,
    val language: String?,
    val sizeBytes: Long?,
    val resourceId: String?,
    val mirrors: List<MirrorInfo>
)

data class SubtitleOption(
    val name: String,
    val url: String
)

data class DownloadStatus(
    val state: String, // running | completed | paused | cancelled | failed
    val downloaded: Long,
    val total: Long,
    val bytesPerSecond: Double,
    val error: String?
)

data class FavoriteItem(
    val subjectId: String,
    val provider: String,
    val title: String,
    val coverUrl: String?,
    val stype: Long
)

data class ResolvedSource(
    val url: String,
    val label: String,
    val headers: List<Pair<String, String>>
)

/**
 * Thin Kotlin wrapper around the JNI functions exported from engine/src/ffi.rs.
 * The native lib is the cdylib output of the vendored Rust engine, built by
 * .github/workflows/build.yml and packaged as jniLibs/<abi>/libmoviebox_tui.so.
 *
 * Search/details/releases fan out across every enabled provider (MovieBox,
 * 4KHDHub, Dramachi, CircleFTP, DhakaFlix) via the Rust-side MovieBoxService.
 * Every CatalogItem/MediaDetails/FavoriteItem carries a `provider` string
 * (e.g. "moviebox", "fourkhdhub", "bdix_circleftp") that must be threaded
 * back into details/listReleases/favoritesToggle calls, since the same
 * subjectId string could in principle collide across two different
 * providers.
 *
 * All calls block on network I/O inside Rust -- always call these from a
 * background thread/coroutine, never the main thread.
 */
object Engine {
    init {
        System.loadLibrary("moviebox_tui")
    }

    fun init(dataDir: String) {
        runCatching { nativeInit(dataDir) }
    }

    private external fun nativeInit(dataDir: String)
    private external fun nativeHomepage(tabId: String, page: Int): String
    private external fun nativeFavoritesList(): String
    private external fun nativeFavoritesToggle(subjectId: String, provider: String): String
    private external fun nativeChapterPages(chapterId: String): String
    private external fun nativeSearch(query: String, page: Int): String
    private external fun nativeDetails(subjectId: String, provider: String): String
    private external fun nativeResolve(subjectId: String, provider: String, season: Int, episode: Int): String
    private external fun nativeListReleases(subjectId: String, provider: String, season: Int, episode: Int): String
    private external fun nativeSubtitles(subjectId: String, resourceId: String, season: Int, episode: Int): String
    private external fun nativeStartDownload(url: String, headersJson: String, destPath: String): String
    private external fun nativeDownloadStatus(id: String): String
    private external fun nativeCancelDownload(id: String): String

    private fun parseCatalogItem(o: JSONObject): CatalogItem {
        val idObj = o.getJSONObject("id")
        return CatalogItem(
            id = idObj.getString("value"),
            provider = idObj.optString("provider", "moviebox"),
            title = o.getString("title"),
            mediaType = o.optString("media_type", "movie"),
            year = o.optStringOrNull("year"),
            posterUrl = o.optStringOrNull("poster_url"),
            seasonCount = o.optIntOrNull("season_count")
        )
    }

    fun chapterPages(chapterId: String): Result<List<String>> = runCatching {
        val json = nativeChapterPages(chapterId)
        failIfError(json)
        val arr = JSONArray(json)
        (0 until arr.length()).map { arr.getString(it) }
    }

    fun search(query: String, page: Int = 0): Result<List<CatalogItem>> = runCatching {
        val json = nativeSearch(query, page)
        failIfError(json)
        val arr = JSONArray(json)
        (0 until arr.length()).map { i -> parseCatalogItem(arr.getJSONObject(i)) }
    }

    fun details(subjectId: String, provider: String): Result<MediaDetails> = runCatching {
        val json = nativeDetails(subjectId, provider)
        failIfError(json)
        val o = JSONObject(json)
        val seasonsArr = o.optJSONArray("seasons") ?: JSONArray()
        val seasons = (0 until seasonsArr.length()).map { i ->
            val s = seasonsArr.getJSONObject(i)
            val epArr = s.optJSONArray("episodes") ?: JSONArray()
            val episodes = (0 until epArr.length()).map { j ->
                val e = epArr.getJSONObject(j)
                EpisodeInfo(
                    season = e.getInt("season"),
                    number = e.getInt("number"),
                    title = e.optStringOrNull("title"),
                    overview = e.optStringOrNull("overview")
                )
            }
            SeasonInfo(number = s.getInt("number"), episodes = episodes)
        }
        val genresArr = o.optJSONArray("genres") ?: JSONArray()
        val genres = (0 until genresArr.length()).map { genresArr.getString(it) }
        val idObj = o.getJSONObject("id")

        MediaDetails(
            id = idObj.getString("value"),
            provider = idObj.optString("provider", provider),
            title = o.getString("title"),
            mediaType = o.optString("media_type", "movie"),
            year = o.optStringOrNull("year"),
            description = o.optStringOrNull("description"),
            tagline = o.optStringOrNull("tagline"),
            imdbRating = o.optStringOrNull("imdb_rating"),
            director = o.optStringOrNull("director"),
            stars = o.optStringOrNull("stars"),
            duration = o.optStringOrNull("duration"),
            posterUrl = o.optStringOrNull("poster_url"),
            genres = genres,
            seasons = seasons
        )
    }

    fun resolve(subjectId: String, provider: String, season: Int, episode: Int): Result<ResolvedSource> = runCatching {
        val json = nativeResolve(subjectId, provider, season, episode)
        failIfError(json)
        val o = JSONObject(json)
        val headersArr = o.optJSONArray("headers") ?: JSONArray()
        val headers = (0 until headersArr.length()).map { i ->
            val pair = headersArr.getJSONArray(i)
            pair.getString(0) to pair.getString(1)
        }
        ResolvedSource(
            url = o.getString("url"),
            label = o.optString("label", ""),
            headers = headers
        )
    }

    fun listReleases(subjectId: String, provider: String, season: Int, episode: Int): Result<List<ReleaseInfo>> = runCatching {
        val json = nativeListReleases(subjectId, provider, season, episode)
        failIfError(json)
        val arr = JSONArray(json)
        (0 until arr.length()).map { i ->
            val r = arr.getJSONObject(i)
            val mirrorsArr = r.optJSONArray("mirrors") ?: JSONArray()
            val mirrors = (0 until mirrorsArr.length()).map { j ->
                val m = mirrorsArr.getJSONObject(j)
                val headersArr = m.optJSONArray("headers") ?: JSONArray()
                val headers = (0 until headersArr.length()).map { k ->
                    val pair = headersArr.getJSONArray(k)
                    pair.getString(0) to pair.getString(1)
                }
                MirrorInfo(
                    label = m.getString("label"),
                    url = m.getString("resolver_url"),
                    headers = headers,
                    directFile = m.optBoolean("direct_file", false)
                )
            }
            ReleaseInfo(
                quality = r.optStringOrNull("quality") ?: "Unknown",
                language = r.optStringOrNull("language"),
                sizeBytes = if (r.has("size_bytes") && !r.isNull("size_bytes")) r.getLong("size_bytes") else null,
                resourceId = r.optStringOrNull("resource_id"),
                mirrors = mirrors
            )
        }
    }

    fun subtitles(subjectId: String, resourceId: String, season: Int, episode: Int): Result<List<SubtitleOption>> = runCatching {
        val json = nativeSubtitles(subjectId, resourceId, season, episode)
        failIfError(json)
        val arr = JSONArray(json)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            SubtitleOption(name = o.getString("name"), url = o.getString("url"))
        }
    }

    fun startDownload(source: ResolvedSource, destPath: String): Result<String> = runCatching {
        val headersJson = JSONArray().apply {
            source.headers.forEach { (k, v) -> put(JSONArray().apply { put(k); put(v) }) }
        }.toString()
        val id = nativeStartDownload(source.url, headersJson, destPath)
        if (id.trim().startsWith("{")) throw RuntimeException(JSONObject(id).optString("error", "failed to start download"))
        id
    }

    fun downloadStatus(id: String): Result<DownloadStatus> = runCatching {
        val json = nativeDownloadStatus(id)
        val o = JSONObject(json)
        // Only a reply with no "state" is a bridge error; a failed download carries "state":"failed" plus its own "error".
        if (!o.has("state") && o.has("error")) throw RuntimeException(o.getString("error"))
        DownloadStatus(
            state = o.getString("state"),
            downloaded = o.optLong("downloaded", 0),
            total = o.optLong("total", 0),
            bytesPerSecond = o.optDouble("bytes_per_second", 0.0),
            error = o.optStringOrNull("error")
        )
    }

    fun cancelDownload(id: String) {
        runCatching { nativeCancelDownload(id) }
    }

    fun homepage(tabId: String = "2", page: Int = 1): Result<List<CatalogItem>> = runCatching {
        val json = nativeHomepage(tabId, page)
        failIfError(json)
        val arr = JSONArray(json)
        (0 until arr.length()).map { i -> parseCatalogItem(arr.getJSONObject(i)) }
    }

    fun favoritesList(): Result<List<FavoriteItem>> = runCatching {
        val json = nativeFavoritesList()
        failIfError(json)
        val arr = JSONArray(json)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            FavoriteItem(
                subjectId = o.getString("subject_id"),
                provider = o.optString("provider", "moviebox"),
                title = o.getString("title"),
                coverUrl = o.optStringOrNull("cover_url"),
                stype = o.optLong("stype", 1)
            )
        }
    }

    fun favoritesToggle(subjectId: String, provider: String): Result<Boolean> = runCatching {
        val json = nativeFavoritesToggle(subjectId, provider)
        failIfError(json)
        JSONObject(json).getBoolean("is_favorite")
    }

    private fun failIfError(json: String) {
        val trimmed = json.trim()
        if (trimmed.startsWith("{") && trimmed.contains("\"error\"")) {
            val msg = JSONObject(trimmed).optString("error", "unknown engine error")
            throw RuntimeException(msg)
        }
    }
}

private fun JSONObject.optStringOrNull(key: String): String? =
    if (has(key) && !isNull(key)) getString(key) else null

private fun JSONObject.optIntOrNull(key: String): Int? =
    if (has(key) && !isNull(key)) getInt(key) else null
