package com.aniciel.app

enum class SourceCategory(val label: String) {
    MOVIES("Movies"),
    ANIME("Anime"),
    MANGA("Manga"),
    ADULT("Adult"),
    SYSTEM("Media engine")
}

enum class SourceState(val label: String) {
    READY("Ready"),
    OPTIONAL("Optional"),
    REFERENCE("Reference"),
    OFFLINE("Offline / disabled")
}

data class SourceEntry(
    val id: String,
    val name: String,
    val category: SourceCategory,
    val state: SourceState,
    val capabilities: Set<String>,
    val note: String = ""
)

/**
 * Central source catalogue. Only entries marked READY are wired directly into
 * the current Rust/Android engine. REFERENCE entries preserve useful source
 * information from the supplied projects without pretending that an old
 * scraper is an Android-ready adapter.
 */
object SourceRegistry {
    val all: List<SourceEntry> = listOf(
        SourceEntry("moviebox", "MovieBox", SourceCategory.MOVIES, SourceState.READY, setOf("catalogue", "details", "stream", "download", "subtitles")),
        SourceEntry("fourkhdhub", "4KHDHub", SourceCategory.MOVIES, SourceState.OPTIONAL, setOf("search", "details", "stream"), "Existing Rust adapter; health-gate before enabling."),
        SourceEntry("circleftp", "CircleFTP (BDIX)", SourceCategory.MOVIES, SourceState.OFFLINE, setOf("search", "details", "stream"), "Network-local provider; disabled by default."),
        SourceEntry("dhakaflix", "DhakaFlix (BDIX)", SourceCategory.MOVIES, SourceState.OFFLINE, setOf("search", "details", "stream"), "Network-local provider; disabled by default."),
        SourceEntry("dramachi", "Dramachi", SourceCategory.ANIME, SourceState.OPTIONAL, setOf("search", "details", "stream"), "Existing Rust adapter; health-gate before enabling."),
        SourceEntry("anidbapp", "AniDB.app", SourceCategory.ANIME, SourceState.READY, setOf("search", "details", "metadata"), "Metadata sidecar already present in the Rust engine."),

        SourceEntry("anime_sama_hls", "Anime-Sama HLS pipeline", SourceCategory.ANIME, SourceState.REFERENCE, setOf("hls", "m3u8", "segments", "ffmpeg"), "Useful extraction architecture from supplied GPL project; not copied into the Android runtime."),
        SourceEntry("ansembed", "Ansembed extractor", SourceCategory.ANIME, SourceState.REFERENCE, setOf("extract", "stream")),
        SourceEntry("embed4me", "Embed4me extractor", SourceCategory.ANIME, SourceState.REFERENCE, setOf("extract", "stream")),
        SourceEntry("filemoon", "Filemoon extractor", SourceCategory.ANIME, SourceState.REFERENCE, setOf("extract", "stream")),
        SourceEntry("luluvdo", "Luluvdo extractor", SourceCategory.ANIME, SourceState.REFERENCE, setOf("extract", "stream")),
        SourceEntry("movearnpre", "Movearnpre extractor", SourceCategory.ANIME, SourceState.REFERENCE, setOf("extract", "stream")),
        SourceEntry("oneupload", "OneUpload extractor", SourceCategory.ANIME, SourceState.REFERENCE, setOf("extract", "stream")),
        SourceEntry("sendvid", "Sendvid extractor", SourceCategory.ANIME, SourceState.REFERENCE, setOf("extract", "stream")),
        SourceEntry("sibnet", "Sibnet extractor", SourceCategory.ANIME, SourceState.REFERENCE, setOf("extract", "stream")),
        SourceEntry("uqload", "Uqload extractor", SourceCategory.ANIME, SourceState.REFERENCE, setOf("extract", "stream")),
        SourceEntry("vidmoly", "Vidmoly extractor", SourceCategory.ANIME, SourceState.REFERENCE, setOf("extract", "stream")),
        SourceEntry("vidzy", "Vidzy extractor", SourceCategory.ANIME, SourceState.REFERENCE, setOf("extract", "stream")),
        SourceEntry("voe", "Voe extractor", SourceCategory.ANIME, SourceState.REFERENCE, setOf("extract", "stream")),
        SourceEntry("zine_hls", "Zine HLS extractor", SourceCategory.SYSTEM, SourceState.REFERENCE, setOf("hls", "m3u8"), "Reference implementation from supplied Zine project."),
        SourceEntry("zine_playwright", "Zine browser interception", SourceCategory.SYSTEM, SourceState.REFERENCE, setOf("source-resolution"), "Desktop/browser reference; not bundled as an Android browser dependency."),
        SourceEntry("zine_ytdlp", "Zine yt-dlp pipeline", SourceCategory.SYSTEM, SourceState.REFERENCE, setOf("direct", "hls", "dash", "merge"), "Reference pipeline; Android uses its native downloader instead."),

        SourceEntry("internetarchive", "Internet Archive", SourceCategory.MOVIES, SourceState.READY, setOf("search", "details", "download")),
        SourceEntry("mangadex", "MangaDex", SourceCategory.MANGA, SourceState.READY, setOf("search", "chapters", "pages", "download")),
        SourceEntry("fanfox", "FanFox", SourceCategory.MANGA, SourceState.REFERENCE, setOf("chapters", "pages", "download")),
        SourceEntry("kunmanga", "KunManga", SourceCategory.MANGA, SourceState.REFERENCE, setOf("chapters", "pages", "download")),
        SourceEntry("mangak", "Mangak", SourceCategory.MANGA, SourceState.REFERENCE, setOf("chapters", "pages", "download")),
        SourceEntry("topmanhua", "TopManhua", SourceCategory.MANGA, SourceState.REFERENCE, setOf("chapters", "pages", "download")),
        SourceEntry("weebcentral", "WeebCentral", SourceCategory.MANGA, SourceState.REFERENCE, setOf("chapters", "pages", "download")),
        SourceEntry("asurascans", "AsuraScans", SourceCategory.MANGA, SourceState.REFERENCE, setOf("chapters", "pages", "download")),
        SourceEntry("manhuaplus", "ManhuaPlus", SourceCategory.MANGA, SourceState.REFERENCE, setOf("chapters", "pages", "download")),
        SourceEntry("projectsuki", "ProjectSuki", SourceCategory.MANGA, SourceState.REFERENCE, setOf("chapters", "pages", "download")),

        // Adult sources are kept as a separate category in the registry. Their
        // adapters are not silently mixed into Movies/Anime/Manga.
        SourceEntry("hanime", "Hanime", SourceCategory.ADULT, SourceState.REFERENCE, setOf("search", "stream", "download")),
        SourceEntry("hanime_red", "Hanime Red", SourceCategory.ADULT, SourceState.REFERENCE, setOf("search", "stream", "download")),
        SourceEntry("hentaicity", "Hentaicity", SourceCategory.ADULT, SourceState.REFERENCE, setOf("search", "stream", "download")),
        SourceEntry("hentaihaven", "HentaiHaven", SourceCategory.ADULT, SourceState.REFERENCE, setOf("search", "stream", "download")),
        SourceEntry("hentaihaven_co", "HentaiHaven Co", SourceCategory.ADULT, SourceState.REFERENCE, setOf("search", "stream", "download")),
        SourceEntry("hentaimama", "HentaiMama", SourceCategory.ADULT, SourceState.REFERENCE, setOf("search", "stream", "download")),
        SourceEntry("hstream", "HStream", SourceCategory.ADULT, SourceState.REFERENCE, setOf("search", "stream", "download")),
        SourceEntry("ohentai", "OHentai", SourceCategory.ADULT, SourceState.REFERENCE, setOf("search", "stream", "download")),
        SourceEntry("oppai_stream", "Oppai Stream", SourceCategory.ADULT, SourceState.REFERENCE, setOf("search", "stream", "download")),
        SourceEntry("pornhub", "Pornhub", SourceCategory.ADULT, SourceState.REFERENCE, setOf("search", "stream", "download")),
        SourceEntry("hentai18", "Hentai18", SourceCategory.ADULT, SourceState.REFERENCE, setOf("chapters", "pages", "download")),
        SourceEntry("hentai20", "Hentai20", SourceCategory.ADULT, SourceState.REFERENCE, setOf("chapters", "pages", "download")),
        SourceEntry("manga18fx", "Manga18FX", SourceCategory.ADULT, SourceState.REFERENCE, setOf("chapters", "pages", "download")),
        SourceEntry("manhwaus", "ManhwaUS", SourceCategory.ADULT, SourceState.REFERENCE, setOf("chapters", "pages", "download")),
        SourceEntry("omegascans", "OmegaScans", SourceCategory.ADULT, SourceState.REFERENCE, setOf("chapters", "pages", "download")),
        SourceEntry("oppai_stream_toon", "Oppai Stream Toon", SourceCategory.ADULT, SourceState.REFERENCE, setOf("chapters", "pages", "download")),
        SourceEntry("asmhentai", "ASMHentai", SourceCategory.ADULT, SourceState.REFERENCE, setOf("chapters", "pages", "download")),
        SourceEntry("nhentai", "NHenTai", SourceCategory.ADULT, SourceState.REFERENCE, setOf("chapters", "pages", "download")),
    )

    fun forCategory(category: SourceCategory): List<SourceEntry> = all.filter { it.category == category }
}
