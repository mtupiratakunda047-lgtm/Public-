package com.aniciel.app

import android.content.Context
import android.os.Environment
import androidx.core.content.edit
import java.io.File

data class StorageVolume(
    val index: Int,
    val label: String,
    val rootPath: String,
    val isRemovable: Boolean
)

/**
 * Download location: public folder outside Android/data.
 * Default: /storage/emulated/0/AniCiel/Downloads
 * (visible in Files app under internal storage → AniCiel)
 */
object DownloadSettings {
    private const val PREFS = "download_settings"
    private const val KEY_VOLUME_INDEX = "volume_index"
    private const val KEY_SUBDIR = "subdir"
    private const val DEFAULT_SUBDIR = "Downloads"
    private const val PUBLIC_FOLDER = "AniCiel"

    /** Primary public root: /storage/emulated/0/AniCiel */
    fun publicAniCielRoot(): File {
        val base = Environment.getExternalStorageDirectory()
        return File(base, PUBLIC_FOLDER)
    }

    fun listVolumes(context: Context): List<StorageVolume> {
        val list = mutableListOf<StorageVolume>()
        // Index 0 — public AniCiel folder (not under Android/data)
        val publicRoot = publicAniCielRoot()
        list += StorageVolume(
            index = 0,
            label = "AniCiel folder (Phone)",
            rootPath = publicRoot.absolutePath,
            isRemovable = false
        )
        // Secondary volumes (SD): /storage/<uuid>/AniCiel when available
        val externals = context.getExternalFilesDirs(null)
        externals.forEachIndexed { i, dir ->
            if (dir == null || i == 0) return@forEachIndexed
            val path = dir.absolutePath
            // Turn .../Android/data/.../files into volume root if possible
            val volRoot = path.substringBefore("/Android/data").ifBlank { null } ?: return@forEachIndexed
            if (volRoot.contains("0000-0000")) return@forEachIndexed
            val ani = File(volRoot, PUBLIC_FOLDER)
            list += StorageVolume(
                index = list.size,
                label = "AniCiel folder (SD)",
                rootPath = ani.absolutePath,
                isRemovable = true
            )
        }
        return list
    }

    fun subdirectory(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_SUBDIR, DEFAULT_SUBDIR) ?: DEFAULT_SUBDIR

    fun selectedVolumeIndex(context: Context): Int =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_VOLUME_INDEX, 0)

    fun save(context: Context, volumeIndex: Int, subdirectory: String) {
        val safeSubdir = subdirectory.trim().ifBlank { DEFAULT_SUBDIR }
            .replace(Regex("[^A-Za-z0-9._\\- /]"), "_")
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit {
            putInt(KEY_VOLUME_INDEX, volumeIndex)
            putString(KEY_SUBDIR, safeSubdir)
        }
    }

    /**
     * Default path example:
     * /storage/emulated/0/AniCiel/Downloads
     */
    fun resolvedDir(context: Context): File {
        val volumes = listVolumes(context)
        val chosenIndex = selectedVolumeIndex(context)
        val volume = volumes.firstOrNull { it.index == chosenIndex } ?: volumes.firstOrNull()
        var root = volume?.rootPath ?: publicAniCielRoot().absolutePath
        if (root.contains("0000-0000")) {
            root = publicAniCielRoot().absolutePath
        }
        val dir = File(root, subdirectory(context))
        if (!dir.exists() && !dir.mkdirs()) {
            // Last resort: still try public Downloads/AniCiel
            val fallback = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                PUBLIC_FOLDER
            )
            fallback.mkdirs()
            return fallback
        }
        return dir
    }
}
