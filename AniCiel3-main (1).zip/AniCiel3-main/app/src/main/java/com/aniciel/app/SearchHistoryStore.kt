package com.aniciel.app

import android.content.Context
import org.json.JSONArray
import java.io.File
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Recent search queries (newest first). Persisted to filesDir/search_history.json.
 */
object SearchHistoryStore {
    private const val MAX = 30
    private val items = CopyOnWriteArrayList<String>()
    private var file: File? = null

    fun init(context: Context) {
        file = File(context.filesDir, "search_history.json")
        load()
    }

    fun all(): List<String> = items.toList()

    fun add(query: String) {
        val q = query.trim()
        if (q.isEmpty()) return
        items.removeAll { it.equals(q, ignoreCase = true) }
        items.add(0, q)
        while (items.size > MAX) items.removeAt(items.lastIndex)
        persist()
    }

    fun remove(query: String) {
        items.removeAll { it.equals(query, ignoreCase = true) }
        persist()
    }

    fun clear() {
        items.clear()
        persist()
    }

    private fun load() {
        val f = file ?: return
        if (!f.exists()) return
        runCatching {
            val arr = JSONArray(f.readText())
            items.clear()
            for (i in 0 until arr.length()) {
                val s = arr.optString(i, "").trim()
                if (s.isNotEmpty()) items.add(s)
            }
        }
    }

    private fun persist() {
        val f = file ?: return
        runCatching {
            val arr = JSONArray()
            items.forEach { arr.put(it) }
            f.writeText(arr.toString())
        }
    }
}
