package com.aniciel.app

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Downloads manga chapter pages to public storage:
 * /storage/emulated/0/AniCiel/Manga/<Title>/Ch_<n>/001.jpg ...
 * Returns local file paths suitable for [MangaReaderActivity].
 */
object MangaOffline {
    fun mangaRoot(): File {
        val base = DownloadSettings.publicAniCielRoot()
        return File(base, "Manga").also { it.mkdirs() }
    }

    fun chapterDir(mangaTitle: String, chapterLabel: String): File {
        val safeManga = mangaTitle.replace(Regex("[^A-Za-z0-9._\\- ]"), "_").trim().ifBlank { "Manga" }
        val safeCh = chapterLabel.replace(Regex("[^A-Za-z0-9._\\- ]"), "_").trim().ifBlank { "Chapter" }
        return File(mangaRoot(), "$safeManga/$safeCh").also { it.mkdirs() }
    }

    /**
     * @return list of absolute local paths (or empty on total failure)
     */
    suspend fun downloadPages(
        context: Context,
        mangaTitle: String,
        chapterLabel: String,
        pageUrls: List<String>,
        onProgress: (done: Int, total: Int) -> Unit = { _, _ -> }
    ): List<String> = withContext(Dispatchers.IO) {
        val dir = chapterDir(mangaTitle, chapterLabel)
        val out = mutableListOf<String>()
        val total = pageUrls.size
        pageUrls.forEachIndexed { index, url ->
            val ext = when {
                url.contains(".png", true) -> "png"
                url.contains(".webp", true) -> "webp"
                else -> "jpg"
            }
            val dest = File(dir, String.format("%03d.%s", index + 1, ext))
            if (dest.exists() && dest.length() > 1024) {
                out += dest.absolutePath
                onProgress(index + 1, total)
                return@forEachIndexed
            }
            try {
                val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 20_000
                    readTimeout = 60_000
                    setRequestProperty("User-Agent", "AniCiel/0.5")
                    instanceFollowRedirects = true
                }
                conn.inputStream.use { input ->
                    dest.outputStream().use { output -> input.copyTo(output) }
                }
                conn.disconnect()
                if (dest.length() > 0) out += dest.absolutePath
            } catch (_: Exception) {
                // skip failed page
            }
            onProgress(index + 1, total)
        }
        out
    }
}
