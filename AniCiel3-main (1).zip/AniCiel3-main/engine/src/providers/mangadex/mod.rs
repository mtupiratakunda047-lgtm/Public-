//! MangaDex provider — public API (`https://api.mangadex.org`).
//!
//! Chapters are mapped to `Season { number: 1, episodes: [...] }` so the
//! existing Android details UI can list them. Page images are fetched via
//! [`MangaDexClient::chapter_pages`] (at-home server). Video `episode_streams`
//! returns empty — manga is not streamed video.

pub mod client;

pub use client::{MangaDexClient, MangaDexError};

use super::models::{CatalogItem, MediaDetails, ProviderError, ProviderKind, Release};
use super::{Provider, ProviderCapabilities, ReleaseProvider};

impl Provider for MangaDexClient {
    fn id(&self) -> ProviderKind {
        ProviderKind::MangaDex
    }

    fn capabilities(&self) -> ProviderCapabilities {
        ProviderCapabilities {
            supports_search: true,
            supports_pagination: true,
            supports_series: true,
            supports_subtitles: false,
            supports_homepage: false,
        }
    }

    async fn search(&self, query: &str, page: usize) -> Result<Vec<CatalogItem>, ProviderError> {
        self.search(query, page).await.map_err(ProviderError::from)
    }

    async fn details(&self, id: &str) -> Result<MediaDetails, ProviderError> {
        self.details(id).await.map_err(ProviderError::from)
    }
}

impl ReleaseProvider for MangaDexClient {
    async fn episode_streams(
        &self,
        _id: &str,
        _season: usize,
        _episode: usize,
    ) -> Result<Vec<Release>, ProviderError> {
        // Manga pages are not video releases. Use `chapter_pages` from the client.
        Ok(Vec::new())
    }
}
