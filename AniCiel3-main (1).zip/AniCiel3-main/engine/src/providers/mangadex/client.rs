//! MangaDex API v5 client.
//! Docs: https://api.mangadex.org/docs/

use crate::providers::models::{
    CatalogItem, Episode, MediaDetails, MediaType, ProviderError, ProviderKind, ProviderMediaId,
    Season,
};
use reqwest::Client;
use serde::Deserialize;
use std::collections::HashMap;
use std::time::Duration;

const API: &str = "https://api.mangadex.org";
const COVER_BASE: &str = "https://uploads.mangadex.org/covers";

#[derive(Debug, thiserror::Error)]
pub enum MangaDexError {
    #[error("Network request failed: {0}")]
    Network(#[from] reqwest::Error),
    #[error("Failed to parse MangaDex response: {0}")]
    Parsing(String),
    #[error("Item not found")]
    NotFound,
    #[error("MangaDex API error: {0}")]
    Api(String),
}

impl From<MangaDexError> for ProviderError {
    fn from(err: MangaDexError) -> Self {
        match err {
            MangaDexError::Network(e) => ProviderError::Network(e.to_string()),
            MangaDexError::Parsing(e) => ProviderError::Parsing(e),
            MangaDexError::NotFound => ProviderError::NotFound,
            MangaDexError::Api(e) => ProviderError::Unavailable(e),
        }
    }
}

#[derive(Debug, Clone)]
pub struct MangaDexClient {
    client: Client,
}

impl Default for MangaDexClient {
    fn default() -> Self {
        Self::new()
    }
}

impl MangaDexClient {
    pub fn new() -> Self {
        let client = crate::net::http_client_builder()
            .timeout(Duration::from_secs(20))
            .user_agent("AniCiel/0.5 (MangaDex provider; +https://github.com/mtupiratakunda047-lgtm/AniCiel3)")
            .build()
            .unwrap_or_default();
        Self { client }
    }

    /// Search manga by title. `page` is 1-based.
    pub async fn search(&self, query: &str, page: usize) -> Result<Vec<CatalogItem>, MangaDexError> {
        let q = query.trim();
        if q.is_empty() {
            return Ok(Vec::new());
        }
        let limit = 20u32;
        let offset = ((page.max(1) - 1) as u32) * limit;
        let url = format!("{API}/manga");
        let resp = self
            .client
            .get(&url)
            .query(&[
                ("title", q.to_string()),
                ("limit", limit.to_string()),
                ("offset", offset.to_string()),
                ("includes[]", "cover_art".to_string()),
                ("order[relevance]", "desc".to_string()),
                ("contentRating[]", "safe".to_string()),
                ("contentRating[]", "suggestive".to_string()),
                ("contentRating[]", "erotica".to_string()),
            ])
            .send()
            .await?
            .error_for_status()?;

        let body: MdResponse<Vec<MdEntity>> = resp.json().await.map_err(|e| {
            MangaDexError::Parsing(format!("search json: {e}"))
        })?;
        if body.result != "ok" {
            return Err(MangaDexError::Api(body.result));
        }
        Ok(body
            .data
            .into_iter()
            .filter_map(|e| e.into_catalog_item())
            .collect())
    }

    /// Manga details + chapter list (as season 1 episodes).
    pub async fn details(&self, id: &str) -> Result<MediaDetails, MangaDexError> {
        let id = id.trim();
        if id.is_empty() {
            return Err(MangaDexError::NotFound);
        }

        let url = format!("{API}/manga/{id}");
        let resp = self
            .client
            .get(&url)
            .query(&[
                ("includes[]", "cover_art".to_string()),
                ("includes[]", "author".to_string()),
            ])
            .send()
            .await?
            .error_for_status()?;
        let body: MdResponse<MdEntity> = resp.json().await.map_err(|e| {
            MangaDexError::Parsing(format!("details json: {e}"))
        })?;
        if body.result != "ok" {
            return Err(MangaDexError::Api(body.result));
        }

        let mut details = body.data.into_media_details()?;
        let chapters = self.fetch_chapters(id).await?;
        details.seasons = vec![Season {
            number: 1,
            episodes: chapters,
        }];
        details.media_type = MediaType::Series;
        Ok(details)
    }

    /// English chapters (and empty language = often official). Paginated feed.
    async fn fetch_chapters(&self, manga_id: &str) -> Result<Vec<Episode>, MangaDexError> {
        let mut episodes = Vec::new();
        let mut offset = 0u32;
        let limit = 100u32;
        loop {
            let url = format!("{API}/manga/{manga_id}/feed");
            let resp = self
                .client
                .get(&url)
                .query(&[
                    ("limit", limit.to_string()),
                    ("offset", offset.to_string()),
                    ("translatedLanguage[]", "en".to_string()),
                    ("order[chapter]", "asc".to_string()),
                    ("includeFuturePublishAt", "0".to_string()),
                    ("includeEmptyPages", "0".to_string()),
                ])
                .send()
                .await?
                .error_for_status()?;
            let body: MdResponse<Vec<MdEntity>> = resp.json().await.map_err(|e| {
                MangaDexError::Parsing(format!("feed json: {e}"))
            })?;
            if body.result != "ok" {
                break;
            }
            let batch_len = body.data.len();
            for (i, ch) in body.data.into_iter().enumerate() {
                if ch.r#type != "chapter" {
                    continue;
                }
                let attrs = ch.attributes.unwrap_or_default();
                let chapter_str = attrs.chapter.clone().unwrap_or_default();
                let number = chapter_str
                    .parse::<f64>()
                    .map(|n| n as usize)
                    .unwrap_or(offset as usize + i + 1)
                    .max(1);
                let title = attrs
                    .chapter_title()
                    .filter(|t| !t.is_empty())
                    .or_else(|| {
                        if chapter_str.is_empty() {
                            Some(format!("Chapter {number}"))
                        } else {
                            Some(format!("Ch. {chapter_str}"))
                        }
                    });
                episodes.push(Episode {
                    season: 1,
                    number,
                    title,
                    overview: Some(ch.id.clone()), // store chapter UUID for page fetch
                });
            }
            offset += limit;
            let total = body.total.unwrap_or(0);
            if batch_len == 0 || offset >= total || offset > 500 {
                break;
            }
        }
        // Dedupe by chapter number keeping first
        let mut seen = HashMap::new();
        episodes.retain(|e| seen.insert(e.number, ()).is_none());
        episodes.sort_by_key(|e| e.number);
        Ok(episodes)
    }

    /// Page image URLs for a chapter UUID (from episode overview).
    pub async fn chapter_pages(&self, chapter_id: &str) -> Result<Vec<String>, MangaDexError> {
        let chapter_id = chapter_id.trim();
        if chapter_id.is_empty() {
            return Err(MangaDexError::NotFound);
        }
        let url = format!("{API}/at-home/server/{chapter_id}");
        let resp = self.client.get(&url).send().await?.error_for_status()?;
        let body: AtHomeResponse = resp.json().await.map_err(|e| {
            MangaDexError::Parsing(format!("at-home json: {e}"))
        })?;
        if body.result != "ok" {
            return Err(MangaDexError::Api(body.result));
        }
        let base = body.base_url.trim_end_matches('/');
        let chapter = body.chapter.ok_or(MangaDexError::NotFound)?;
        let hash = chapter.hash;
        let pages = chapter.data;
        Ok(pages
            .into_iter()
            .map(|file| format!("{base}/data/{hash}/{file}"))
            .collect())
    }
}

// --- JSON shapes (subset) ---

#[derive(Debug, Deserialize)]
struct MdResponse<T> {
    result: String,
    data: T,
    total: Option<u32>,
}

#[derive(Debug, Deserialize)]
struct MdEntity {
    id: String,
    r#type: String,
    attributes: Option<MdAttributes>,
    relationships: Option<Vec<MdRelationship>>,
}

#[derive(Debug, Default, Deserialize)]
struct MdAttributes {
    /// Manga: localized map; Chapter: plain string — accept either via Value.
    #[serde(default)]
    title: Option<serde_json::Value>,
    description: Option<HashMap<String, String>>,
    year: Option<u32>,
    status: Option<String>,
    chapter: Option<String>,
    #[serde(default)]
    tags: Vec<MdTag>,
    #[serde(rename = "fileName", alias = "file_name")]
    file_name: Option<String>,
}

impl MdAttributes {
    fn chapter_title(&self) -> Option<String> {
        match &self.title {
            Some(serde_json::Value::String(s)) => Some(s.clone()),
            Some(serde_json::Value::Object(map)) => map
                .get("en")
                .and_then(|v| v.as_str())
                .map(|s| s.to_string())
                .or_else(|| {
                    map.values()
                        .find_map(|v| v.as_str().map(|s| s.to_string()))
                }),
            _ => None,
        }
    }

    fn manga_title_map(&self) -> Option<HashMap<String, String>> {
        match &self.title {
            Some(serde_json::Value::Object(map)) => {
                let mut out = HashMap::new();
                for (k, v) in map {
                    if let Some(s) = v.as_str() {
                        out.insert(k.clone(), s.to_string());
                    }
                }
                if out.is_empty() {
                    None
                } else {
                    Some(out)
                }
            }
            Some(serde_json::Value::String(s)) => {
                let mut out = HashMap::new();
                out.insert("en".into(), s.clone());
                Some(out)
            }
            _ => None,
        }
    }
}

#[derive(Debug, Deserialize)]
struct MdTag {
    attributes: Option<MdTagAttrs>,
}

#[derive(Debug, Deserialize)]
struct MdTagAttrs {
    name: Option<HashMap<String, String>>,
}

#[derive(Debug, Deserialize)]
struct MdRelationship {
    id: String,
    r#type: String,
    attributes: Option<MdAttributes>,
}

#[derive(Debug, Deserialize)]
struct AtHomeResponse {
    result: String,
    base_url: String,
    chapter: Option<AtHomeChapter>,
}

#[derive(Debug, Deserialize)]
struct AtHomeChapter {
    hash: String,
    data: Vec<String>,
}

impl MdEntity {
    fn pick_title(attrs: &MdAttributes) -> String {
        attrs
            .manga_title_map()
            .and_then(|m| m.get("en").cloned().or_else(|| m.values().next().cloned()))
            .unwrap_or_else(|| "Unknown".into())
    }

    fn pick_description(attrs: &MdAttributes) -> Option<String> {
        attrs.description.as_ref().and_then(|m| {
            m.get("en")
                .or_else(|| m.values().next())
                .cloned()
                .filter(|s| !s.is_empty())
        })
    }

    fn cover_url(&self) -> Option<String> {
        let rels = self.relationships.as_ref()?;
        let cover = rels.iter().find(|r| r.r#type == "cover_art")?;
        let file = cover.attributes.as_ref()?.file_name.as_ref()?;
        Some(format!("{COVER_BASE}/{}/{file}", self.id))
    }

    fn genres(&self) -> Vec<String> {
        let attrs = match &self.attributes {
            Some(a) => a,
            None => return Vec::new(),
        };
        attrs
            .tags
            .iter()
            .filter_map(|t| {
                t.attributes
                    .as_ref()?
                    .name
                    .as_ref()?
                    .get("en")
                    .cloned()
            })
            .collect()
    }

    fn into_catalog_item(self) -> Option<CatalogItem> {
        if self.r#type != "manga" {
            return None;
        }
        let attrs = self.attributes.as_ref()?;
        let title = Self::pick_title(attrs);
        let poster = self.cover_url();
        Some(CatalogItem {
            id: ProviderMediaId {
                provider: ProviderKind::MangaDex,
                value: self.id,
            },
            title,
            media_type: MediaType::Series,
            year: attrs.year.map(|y| y.to_string()),
            poster_url: poster,
            season_count: Some(1),
        })
    }

    fn into_media_details(self) -> Result<MediaDetails, MangaDexError> {
        if self.r#type != "manga" {
            return Err(MangaDexError::Parsing("not a manga entity".into()));
        }
        let attrs = self
            .attributes
            .as_ref()
            .ok_or_else(|| MangaDexError::Parsing("missing attributes".into()))?;
        Ok(MediaDetails {
            id: ProviderMediaId {
                provider: ProviderKind::MangaDex,
                value: self.id.clone(),
            },
            title: Self::pick_title(attrs),
            media_type: MediaType::Series,
            year: attrs.year.map(|y| y.to_string()),
            description: Self::pick_description(attrs),
            tagline: attrs.status.clone(),
            imdb_rating: None,
            director: None,
            stars: None,
            prints: None,
            audios: None,
            poster_url: self.cover_url(),
            duration: None,
            genres: self.genres(),
            seasons: Vec::new(),
            dubs: Vec::new(),
        })
    }
}
