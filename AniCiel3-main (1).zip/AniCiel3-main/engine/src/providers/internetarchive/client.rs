//! Internet Archive Advanced Search + Metadata API client.
//! https://archive.org/developers/

use crate::providers::models::{
    CatalogItem, MediaDetails, MediaType, ProviderError, ProviderKind, ProviderMediaId, Release,
    SourceMirror,
};
use reqwest::Client;
use serde::Deserialize;
use std::time::Duration;

const SEARCH_URL: &str = "https://archive.org/advancedsearch.php";
const META_URL: &str = "https://archive.org/metadata";
const DOWNLOAD_BASE: &str = "https://archive.org/download";

#[derive(Debug, thiserror::Error)]
pub enum InternetArchiveError {
    #[error("Network request failed: {0}")]
    Network(#[from] reqwest::Error),
    #[error("Failed to parse Internet Archive response: {0}")]
    Parsing(String),
    #[error("Item not found")]
    NotFound,
}

impl From<InternetArchiveError> for ProviderError {
    fn from(err: InternetArchiveError) -> Self {
        match err {
            InternetArchiveError::Network(e) => ProviderError::Network(e.to_string()),
            InternetArchiveError::Parsing(e) => ProviderError::Parsing(e),
            InternetArchiveError::NotFound => ProviderError::NotFound,
        }
    }
}

#[derive(Debug, Clone)]
pub struct InternetArchiveClient {
    client: Client,
}

impl Default for InternetArchiveClient {
    fn default() -> Self {
        Self::new()
    }
}

impl InternetArchiveClient {
    pub fn new() -> Self {
        let client = crate::net::http_client_builder()
            .timeout(Duration::from_secs(25))
            .user_agent("AniCiel/0.5 (InternetArchive provider)")
            .build()
            .unwrap_or_default();
        Self { client }
    }

    /// Search movies + texts (comics/books). Page is 1-based.
    pub async fn search(
        &self,
        query: &str,
        page: usize,
    ) -> Result<Vec<CatalogItem>, InternetArchiveError> {
        let q = query.trim();
        if q.is_empty() {
            return Ok(Vec::new());
        }
        let page = page.max(1);
        // Prefer movies and texts; user query in title/description
        let lucene = format!(
            "(mediatype:movies OR mediatype:texts) AND ({q})"
        );
        let resp = self
            .client
            .get(SEARCH_URL)
            .query(&[
                ("q", lucene.as_str()),
                ("fl[]", "identifier"),
                ("fl[]", "title"),
                ("fl[]", "year"),
                ("fl[]", "mediatype"),
                ("fl[]", "description"),
                ("rows", "20"),
                ("page", &page.to_string()),
                ("output", "json"),
            ])
            .send()
            .await?
            .error_for_status()?;

        let body: SearchResponse = resp.json().await.map_err(|e| {
            InternetArchiveError::Parsing(format!("search json: {e}"))
        })?;

        Ok(body
            .response
            .docs
            .into_iter()
            .filter_map(|d| d.into_catalog_item())
            .collect())
    }

    pub async fn details(&self, id: &str) -> Result<MediaDetails, InternetArchiveError> {
        let id = id.trim();
        if id.is_empty() {
            return Err(InternetArchiveError::NotFound);
        }
        let url = format!("{META_URL}/{id}");
        let resp = self.client.get(&url).send().await?.error_for_status()?;
        let body: MetaResponse = resp.json().await.map_err(|e| {
            InternetArchiveError::Parsing(format!("meta json: {e}"))
        })?;
        let meta = body.metadata.ok_or(InternetArchiveError::NotFound)?;
        let title = meta
            .title
            .as_ref()
            .map(|t| match t {
                MetaString::One(s) => s.clone(),
                MetaString::Many(v) => v.first().cloned().unwrap_or_else(|| id.to_string()),
            })
            .unwrap_or_else(|| id.to_string());
        let description = meta.description.as_ref().map(|t| match t {
            MetaString::One(s) => s.clone(),
            MetaString::Many(v) => v.join("\n"),
        });
        let year = meta.year.clone();
        let media_type = match meta.mediatype.as_deref() {
            Some("movies") | Some("movie") => MediaType::Movie,
            _ => MediaType::Movie, // texts still playable/downloadable as single item
        };
        let poster = body
            .files
            .as_ref()
            .and_then(|files| {
                files.iter().find(|f| {
                    let n = f.name.to_lowercase();
                    n.contains("__ia_thumb") || n.ends_with("_thumb.jpg") || n.contains("thumb")
                })
            })
            .map(|f| format!("{DOWNLOAD_BASE}/{id}/{}", f.name));

        Ok(MediaDetails {
            id: ProviderMediaId {
                provider: ProviderKind::InternetArchive,
                value: id.to_string(),
            },
            title,
            media_type,
            year,
            description,
            tagline: meta.mediatype.clone(),
            imdb_rating: None,
            director: None,
            stars: None,
            prints: None,
            audios: None,
            poster_url: poster,
            duration: None,
            genres: meta.subject.unwrap_or_default(),
            seasons: Vec::new(),
            dubs: Vec::new(),
        })
    }

    /// Playable/downloadable files (mp4, mkv, pdf, cbz, etc.) as releases.
    pub async fn list_files(&self, id: &str) -> Result<Vec<Release>, InternetArchiveError> {
        let id = id.trim();
        let url = format!("{META_URL}/{id}");
        let resp = self.client.get(&url).send().await?.error_for_status()?;
        let body: MetaResponse = resp.json().await.map_err(|e| {
            InternetArchiveError::Parsing(format!("meta json: {e}"))
        })?;
        let files = body.files.unwrap_or_default();
        let mut releases = Vec::new();
        for f in files {
            let name = f.name.clone();
            let lower = name.to_lowercase();
            let ok = lower.ends_with(".mp4")
                || lower.ends_with(".mkv")
                || lower.ends_with(".webm")
                || lower.ends_with(".avi")
                || lower.ends_with(".pdf")
                || lower.ends_with(".cbz")
                || lower.ends_with(".cbr")
                || lower.ends_with(".epub");
            if !ok {
                continue;
            }
            let url = format!("{DOWNLOAD_BASE}/{id}/{name}");
            let quality = f.format.clone().unwrap_or_else(|| {
                name.rsplit('.').next().unwrap_or("file").to_uppercase()
            });
            let size = f.size.and_then(|s| s.parse::<u64>().ok());
            releases.push(Release {
                provider: ProviderKind::InternetArchive,
                filename: name.clone(),
                quality: Some(quality),
                codec: None,
                language: None,
                size_bytes: size,
                season: None,
                episode: None,
                resource_id: Some(name.clone()),
                mirrors: vec![SourceMirror {
                    label: name,
                    resolver_url: url,
                    headers: Vec::new(),
                    direct_file: true,
                }],
            });
        }
        if releases.is_empty() {
            return Err(InternetArchiveError::NotFound);
        }
        Ok(releases)
    }
}

// --- JSON ---

#[derive(Debug, Deserialize)]
struct SearchResponse {
    response: SearchInner,
}

#[derive(Debug, Deserialize)]
struct SearchInner {
    docs: Vec<SearchDoc>,
}

#[derive(Debug, Deserialize)]
struct SearchDoc {
    identifier: String,
    title: Option<String>,
    year: Option<String>,
    mediatype: Option<String>,
}

impl SearchDoc {
    fn into_catalog_item(self) -> Option<CatalogItem> {
        let title = self.title.filter(|t| !t.is_empty())?;
        let media_type = MediaType::Movie;
        Some(CatalogItem {
            id: ProviderMediaId {
                provider: ProviderKind::InternetArchive,
                value: self.identifier.clone(),
            },
            title,
            media_type,
            year: self.year,
            poster_url: Some(format!(
                "https://archive.org/services/img/{}",
                self.identifier
            )),
            season_count: None,
        })
    }
}

#[derive(Debug, Deserialize)]
struct MetaResponse {
    metadata: Option<IaMetadata>,
    files: Option<Vec<IaFile>>,
}

#[derive(Debug, Deserialize)]
struct IaMetadata {
    title: Option<MetaString>,
    description: Option<MetaString>,
    year: Option<String>,
    mediatype: Option<String>,
    subject: Option<Vec<String>>,
}

#[derive(Debug, Deserialize)]
#[serde(untagged)]
enum MetaString {
    One(String),
    Many(Vec<String>),
}

#[derive(Debug, Deserialize)]
struct IaFile {
    name: String,
    size: Option<String>,
    format: Option<String>,
}
