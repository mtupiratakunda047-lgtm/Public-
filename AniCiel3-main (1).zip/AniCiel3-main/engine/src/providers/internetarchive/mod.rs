//! Internet Archive provider — public search + metadata + download URLs.
//! Legal/public collections only as presented by archive.org.

pub mod client;

pub use client::{InternetArchiveClient, InternetArchiveError};

use super::models::{CatalogItem, MediaDetails, ProviderError, ProviderKind, Release};
use super::{Provider, ProviderCapabilities, ReleaseProvider};

impl Provider for InternetArchiveClient {
    fn id(&self) -> ProviderKind {
        ProviderKind::InternetArchive
    }

    fn capabilities(&self) -> ProviderCapabilities {
        ProviderCapabilities {
            supports_search: true,
            supports_pagination: true,
            supports_series: false,
            supports_subtitles: false,
            supports_homepage: false,
        }
    }

    async fn search(&self, query: &str, page: usize) -> Result<Vec<CatalogItem>, ProviderError> {
        self.search(query, page).await.map_err(ProviderError::from)
    }

    async fn details(&self, id: &str) -> Result<MediaDetails, ProviderError> {
        self.details(id).await.map_err(ProviderError::from)
    }
}

impl ReleaseProvider for InternetArchiveClient {
    async fn episode_streams(
        &self,
        id: &str,
        _season: usize,
        _episode: usize,
    ) -> Result<Vec<Release>, ProviderError> {
        self.list_files(id).await.map_err(ProviderError::from)
    }
}
