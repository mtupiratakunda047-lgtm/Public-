//! JNI entry points for the native Compose UI (Engine.kt on the Kotlin
//! side), exposed as plain JSON strings so we don't have to hand-mirror
//! every Rust struct as a JNI type. Each call is synchronous from Java's
//! point of view (it blocks on a fresh Tokio runtime internally) -- the
//! Kotlin side is responsible for calling these off the main thread.
//!
//! Search/details/releases now fan out across every provider in
//! ProviderKind::ENABLED (MovieBox, 4KHDHub, Dramachi, CircleFTP,
//! DhakaFlix) via the same MovieBoxService the TUI itself uses. Stremio
//! Addons aren't wired in yet -- they need a manifest URL as extra
//! context that the UI doesn't collect yet.

use jni::JNIEnv;
use jni::objects::{JClass, JString};
use jni::sys::{jint, jstring};

use crate::providers::ReleaseProvider;
use crate::providers::anidbapp::{self, AniDbAppClient};
use crate::providers::models::{ProviderError, ProviderKind, Release};
use crate::service::MovieBoxService;

fn runtime() -> tokio::runtime::Runtime {
    tokio::runtime::Builder::new_current_thread()
        .enable_all()
        .build()
        .expect("failed to build tokio runtime")
}

fn to_jstring(env: &mut JNIEnv, s: &str) -> jstring {
    env.new_string(s)
        .expect("failed to allocate JString")
        .into_raw()
}

fn error_json(msg: &str) -> String {
    let escaped = msg.replace('\\', "\\\\").replace('"', "\\\"");
    format!("{{\"error\":\"{escaped}\"}}")
}

/// Runs `f` with a panic guard so a bug in scraper/parsing code for one
/// call (malformed HTML, an unexpected JSON shape from a site that changed
/// its layout, etc.) surfaces as an error string to Kotlin instead of
/// aborting the whole process -- Rust panics cross the JNI boundary as a
/// hard crash otherwise, taking the entire app down with them. Each call
/// site builds fresh state (a new MovieBoxService, a new runtime) and
/// discards it immediately after, so there's nothing left over for a
/// panic mid-call to leave in a bad state -- AssertUnwindSafe is the
/// correct escape hatch here rather than fighting the auto-trait checker.
/// Locks a mutex, recovering the data if another thread panicked while holding it.
fn lock<T>(m: &Mutex<T>) -> std::sync::MutexGuard<'_, T> {
    m.lock().unwrap_or_else(|e| e.into_inner())
}

fn guarded(f: impl FnOnce() -> String) -> String {
    match std::panic::catch_unwind(std::panic::AssertUnwindSafe(f)) {
        Ok(json) => json,
        Err(_) => error_json("internal error (the engine hit a bug processing this request)"),
    }
}

/// How long a single provider gets to answer a search before we give up on
/// it and return whatever the others found. Keeps one slow or unreachable
/// provider (BDIX sources are unreachable outside Bangladesh's local
/// network, for instance) from stalling the whole search.
const PROVIDER_TIMEOUT: std::time::Duration = std::time::Duration::from_secs(8);

/// Parses the provider strings Kotlin round-trips back to us (they're
/// exactly what CatalogItem/MediaDetails.id.provider serialized as, e.g.
/// "moviebox", "fourkhdhub", "bdix_circleftp") into a ProviderKind.
fn parse_provider(s: &str) -> Option<ProviderKind> {
    serde_json::from_value(serde_json::Value::String(s.to_string())).ok()
}

/// Canonical string form of a ProviderKind, matching its own serde rename
/// (used when we need to hand a provider back to something that wants a
/// &str, like FavoriteItem::from_details).
fn provider_str(p: ProviderKind) -> String {
    serde_json::to_value(p)
        .ok()
        .and_then(|v| v.as_str().map(str::to_string))
        .unwrap_or_else(|| "moviebox".to_string())
}

/// Fetches releases (quality + mirrors) for one episode from whichever
/// provider it came from. MovieBox has its own bespoke resolver flow;
/// the other four enabled providers share the generic ReleaseProvider
/// trait. Addons aren't supported yet (see module doc comment).
async fn fetch_releases(
    service: &MovieBoxService,
    provider: ProviderKind,
    subject_id: &str,
    season: usize,
    episode: usize,
) -> Result<Vec<Release>, ProviderError> {
    match provider {
        ProviderKind::MovieBox => {
            let payload = service
                .client
                .get_play_info(subject_id, season, episode)
                .await
                .map_err(|e| ProviderError::Network(e.to_string()))?;
            Ok(crate::providers::moviebox::adapt::moviebox_play_info_json_to_releases(
                &payload,
                season,
                episode,
                service.client.user_agent(),
            ))
        }
        ProviderKind::FourKHdHub => {
            let fourk = service
                .fourk_client
                .as_ref()
                .ok_or_else(|| ProviderError::Unavailable("4KHDHub is unavailable".to_string()))?;
            fourk.episode_streams(subject_id, season, episode).await
        }
        ProviderKind::Dramachi => {
            service
                .dramachi_client
                .episode_streams(subject_id, season, episode)
                .await
                .map_err(ProviderError::from)
        }
        ProviderKind::BdixCircleFtp => {
            service
                .circleftp_client
                .episode_streams(subject_id, season, episode)
                .await
        }
        ProviderKind::BdixDhakaFlix => {
            service
                .dhakaflix_client
                .episode_streams(subject_id, season, episode)
                .await
        }
        ProviderKind::MangaDex => Ok(Vec::new()),
        ProviderKind::InternetArchive => {
            let svc = MovieBoxService::new();
            ReleaseProvider::episode_streams(&svc.internetarchive_client, subject_id, season, episode).await
        }
        ProviderKind::Addons => Err(ProviderError::Unavailable(
            "Addon sources aren't wired into the app yet".to_string(),
        )),
    }
}

/// JNI: Engine.nativeSearch(query, page) -> JSON array of CatalogItem,
/// aggregated across every enabled provider (MovieBox, 4KHDHub, Dramachi,
/// CircleFTP, DhakaFlix). One provider failing doesn't drop the others --
/// their results are just skipped.
#[unsafe(no_mangle)]
pub extern "system" fn Java_com_aniciel_app_Engine_nativeSearch<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    query: JString<'local>,
    page: jint,
) -> jstring {
    let query: String = match env.get_string(&query) {
        Ok(q) => q.into(),
        Err(_) => return to_jstring(&mut env, &error_json("invalid query string")),
    };
    let page = page.max(0) as usize;

    let json = guarded(|| {
        let all: Vec<serde_json::Value> = runtime().block_on(async {
            let service = MovieBoxService::new();
            let anidb = AniDbAppClient::new();

            let provider_futures = ProviderKind::ENABLED.iter().map(|&provider| {
                let service = &service;
                let query = &query;
                async move {
                    tokio::time::timeout(PROVIDER_TIMEOUT, service.search_typed(provider, query, page))
                        .await
                        .unwrap_or_else(|_| {
                            Err(ProviderError::Unavailable(format!(
                                "{provider:?} timed out"
                            )))
                        })
                }
            });
            let anidb_future = async {
                tokio::time::timeout(PROVIDER_TIMEOUT, anidb.search(&query))
                    .await
                    .unwrap_or_else(|_| Err("anidbapp timed out".to_string()))
                    .unwrap_or_default()
            };

            let (results, anidb_items) = futures::future::join(
                futures::future::join_all(provider_futures),
                anidb_future,
            )
            .await;

            // AniDB.app only has a first page; ask for it only once.
            let mut merged: Vec<serde_json::Value> = results
                .into_iter()
                .filter_map(|r| r.ok())
                .flatten()
                .filter_map(|item| serde_json::to_value(&item).ok())
                .collect();
            if page == 0 {
                merged.extend(anidb_items);
            }
            merged
        });
        serde_json::to_string(&all).unwrap_or_else(|_| "[]".to_string())
    });
    to_jstring(&mut env, &json)
}

/// JNI: Engine.nativeDetails(subjectId, provider) -> JSON MediaDetails
#[unsafe(no_mangle)]
pub extern "system" fn Java_com_aniciel_app_Engine_nativeDetails<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    subject_id: JString<'local>,
    provider: JString<'local>,
) -> jstring {
    let subject_id: String = match env.get_string(&subject_id) {
        Ok(q) => q.into(),
        Err(_) => return to_jstring(&mut env, &error_json("invalid subjectId string")),
    };
    let provider_str_in: String = env
        .get_string(&provider)
        .map(|s| s.into())
        .unwrap_or_default();

    // AniDB.app is a sidecar provider (not a ProviderKind), handled directly.
    if provider_str_in == anidbapp::PROVIDER_ID {
        let json = guarded(|| {
            match runtime().block_on(AniDbAppClient::new().details(&subject_id)) {
                Ok(details) => serde_json::to_string(&details).unwrap_or_else(|_| "null".to_string()),
                Err(e) => error_json(&e),
            }
        });
        return to_jstring(&mut env, &json);
    }

    let provider = match parse_provider(&provider_str_in) {
        Some(p) => p,
        None => return to_jstring(&mut env, &error_json("unknown provider")),
    };

    let json = guarded(|| {
        let result = runtime().block_on(async {
            let service = MovieBoxService::new();
            service.details_typed(provider, &subject_id).await
        });

        match result {
            Ok(details) => serde_json::to_string(&details).unwrap_or_else(|_| "null".to_string()),
            Err(e) => error_json(&e.to_string()),
        }
    });

    to_jstring(&mut env, &json)
}

/// JNI: Engine.nativeResolve(subjectId, provider, season, episode) ->
/// JSON { url, headers: [[k,v],...], subtitle, label } or {"error": ...}
///
/// v1: picks the first direct-file mirror from the first release returned.
/// Multi-mirror fallback / resolver-chain handling (what the TUI's
/// playback.rs does interactively) isn't replicated yet.
#[unsafe(no_mangle)]
pub extern "system" fn Java_com_aniciel_app_Engine_nativeResolve<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    subject_id: JString<'local>,
    provider: JString<'local>,
    season: jint,
    episode: jint,
) -> jstring {
    let subject_id: String = match env.get_string(&subject_id) {
        Ok(q) => q.into(),
        Err(_) => return to_jstring(&mut env, &error_json("invalid subjectId string")),
    };
    let provider_str_in: String = env
        .get_string(&provider)
        .map(|s| s.into())
        .unwrap_or_default();
    let provider = match parse_provider(&provider_str_in) {
        Some(p) => p,
        None => return to_jstring(&mut env, &error_json("unknown provider")),
    };
    let season = season.max(0) as usize;
    let episode = episode.max(0) as usize;

    let json = guarded(|| {
        let result = runtime().block_on(async {
            let service = MovieBoxService::new();
            fetch_releases(&service, provider, &subject_id, season, episode).await
        });

        match result {
            Ok(releases) => {
                let mirror = releases
                    .iter()
                    .flat_map(|r| r.mirrors.iter())
                    .find(|m| m.direct_file)
                    .or_else(|| releases.first().and_then(|r| r.mirrors.first()));

                match mirror {
                    Some(m) => {
                        let headers: Vec<String> = m
                            .headers
                            .iter()
                            .map(|(k, v)| {
                                format!(
                                    "[\"{}\",\"{}\"]",
                                    k.replace('"', "\\\""),
                                    v.replace('"', "\\\"")
                                )
                            })
                            .collect();
                        format!(
                            "{{\"url\":\"{}\",\"label\":\"{}\",\"headers\":[{}]}}",
                            m.resolver_url.replace('"', "\\\""),
                            m.label.replace('"', "\\\""),
                            headers.join(",")
                        )
                    }
                    None => error_json("no playable mirror found"),
                }
            }
            Err(e) => error_json(&e.to_string()),
        }
    });

    to_jstring(&mut env, &json)
}

/// JNI: Engine.nativeListReleases(subjectId, provider, season, episode) ->
/// JSON array of Release (each with .quality and .mirrors), or {"error": ...}
/// Used to build the quality picker before playing/downloading.
#[unsafe(no_mangle)]
pub extern "system" fn Java_com_aniciel_app_Engine_nativeListReleases<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    subject_id: JString<'local>,
    provider: JString<'local>,
    season: jint,
    episode: jint,
) -> jstring {
    let subject_id: String = match env.get_string(&subject_id) {
        Ok(q) => q.into(),
        Err(_) => return to_jstring(&mut env, &error_json("invalid subjectId string")),
    };
    let provider_str_in: String = env
        .get_string(&provider)
        .map(|s| s.into())
        .unwrap_or_default();

    // AniDB.app is a sidecar provider (not a ProviderKind), handled directly.
    if provider_str_in == anidbapp::PROVIDER_ID {
        let episode = episode.max(0) as usize;
        let json = guarded(|| {
            match runtime().block_on(AniDbAppClient::new().releases(&subject_id, episode)) {
                Ok(releases) => serde_json::to_string(&releases).unwrap_or_else(|_| "[]".to_string()),
                Err(e) => error_json(&e),
            }
        });
        return to_jstring(&mut env, &json);
    }

    let provider = match parse_provider(&provider_str_in) {
        Some(p) => p,
        None => return to_jstring(&mut env, &error_json("unknown provider")),
    };
    let season = season.max(0) as usize;
    let episode = episode.max(0) as usize;

    let json = guarded(|| {
        let result = runtime().block_on(async {
            let service = MovieBoxService::new();
            fetch_releases(&service, provider, &subject_id, season, episode).await
        });

        match result {
            Ok(releases) => serde_json::to_string(&releases).unwrap_or_else(|_| "[]".to_string()),
            Err(e) => error_json(&e.to_string()),
        }
    });

    to_jstring(&mut env, &json)
}

/// JNI: Engine.nativeSubtitles(subjectId, provider, resourceId, season, episode)
/// -> JSON array of { name, url } or {"error": ...}
/// MovieBox-only for now: resource_id (which this needs) only comes back
/// on MovieBox releases -- the other providers' ReleaseProvider results
/// don't carry one, so their episodes just won't offer subtitle tracks.
#[unsafe(no_mangle)]
pub extern "system" fn Java_com_aniciel_app_Engine_nativeSubtitles<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    subject_id: JString<'local>,
    resource_id: JString<'local>,
    season: jint,
    episode: jint,
) -> jstring {
    let subject_id: String = match env.get_string(&subject_id) {
        Ok(s) => s.into(),
        Err(_) => return to_jstring(&mut env, &error_json("invalid subjectId string")),
    };
    let resource_id: String = match env.get_string(&resource_id) {
        Ok(s) => s.into(),
        Err(_) => return to_jstring(&mut env, &error_json("invalid resourceId string")),
    };
    let season = season.max(0) as usize;
    let episode = episode.max(0) as usize;

    let json = guarded(|| {
        let result = runtime().block_on(async {
            let service = MovieBoxService::new();
            service
                .get_ext_captions(&subject_id, &resource_id, &[], season, episode)
                .await
        });

        match result {
            Ok(subs) => serde_json::to_string(&subs).unwrap_or_else(|_| "[]".to_string()),
            Err(e) => error_json(&e),
        }
    });

    to_jstring(&mut env, &json)
}
// A download runs on its own OS thread (with its own small Tokio runtime)
// so the JNI call that starts it returns immediately with an id; progress
// is polled from Kotlin via nativeDownloadStatus rather than pushed via a
// JNI callback, which keeps this side of the bridge much simpler (no need
// to attach the download thread to the JVM).
// ---------------------------------------------------------------------

use std::collections::HashMap;
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::{Arc, Mutex, OnceLock};

use crate::download::{self, DownloadOutcome};
use crate::hls_download::{self, HlsOutcome};

#[derive(Clone)]
struct DownloadHandle {
    cancel: Arc<AtomicBool>,
    downloaded: Arc<AtomicU64>,
    total: Arc<AtomicU64>, // 0 == unknown
    bytes_per_second: Arc<Mutex<f64>>,
    state: Arc<Mutex<DownloadState>>,
}

#[derive(Clone)]
enum DownloadState {
    Running,
    Completed,
    Paused,
    Cancelled,
    Failed(String),
}

fn registry() -> &'static Mutex<HashMap<String, DownloadHandle>> {
    static REGISTRY: OnceLock<Mutex<HashMap<String, DownloadHandle>>> = OnceLock::new();
    REGISTRY.get_or_init(|| Mutex::new(HashMap::new()))
}

/// JNI: Engine.nativeStartDownload(url, headersJson, destPath) -> download id (String)
/// headersJson is a JSON array of [key, value] pairs, e.g. from
/// ResolvedSource.headers, or "[]" for none.
#[unsafe(no_mangle)]
pub extern "system" fn Java_com_aniciel_app_Engine_nativeStartDownload<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    url: JString<'local>,
    headers_json: JString<'local>,
    dest_path: JString<'local>,
) -> jstring {
    let url: String = match env.get_string(&url) {
        Ok(s) => s.into(),
        Err(_) => return to_jstring(&mut env, &error_json("invalid url string")),
    };
    let headers_json: String = env
        .get_string(&headers_json)
        .map(|s| s.into())
        .unwrap_or_else(|_| "[]".to_string());
    let dest_path: String = match env.get_string(&dest_path) {
        Ok(s) => s.into(),
        Err(_) => return to_jstring(&mut env, &error_json("invalid destPath string")),
    };

    let headers: Vec<(String, String)> =
        serde_json::from_str::<Vec<(String, String)>>(&headers_json).unwrap_or_default();

    let id = format!(
        "dl-{}",
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|d| d.as_nanos())
            .unwrap_or(0)
    );

    let handle = DownloadHandle {
        cancel: Arc::new(AtomicBool::new(false)),
        downloaded: Arc::new(AtomicU64::new(0)),
        total: Arc::new(AtomicU64::new(0)),
        bytes_per_second: Arc::new(Mutex::new(0.0)),
        state: Arc::new(Mutex::new(DownloadState::Running)),
    };
    lock(registry()).insert(id.clone(), handle.clone());

    let thread_id = id.clone();
    std::thread::spawn(move || {
        let rt = runtime();
        let cancel_for_job = handle.cancel.clone();
        let downloaded_for_report = handle.downloaded.clone();
        let total_for_report = handle.total.clone();
        let bps_for_report = handle.bytes_per_second.clone();
        let is_hls = url.to_ascii_lowercase().contains(".m3u8");

        let job = std::panic::AssertUnwindSafe(|| rt.block_on(async move {
            let mut builder = reqwest::Client::builder();
            if !headers.is_empty() {
                let mut header_map = reqwest::header::HeaderMap::new();
                for (k, v) in &headers {
                    if let (Ok(name), Ok(value)) = (
                        reqwest::header::HeaderName::from_bytes(k.as_bytes()),
                        reqwest::header::HeaderValue::from_str(v),
                    ) {
                        header_map.insert(name, value);
                    }
                }
                builder = builder.default_headers(header_map);
            }
            let client = match builder.build() {
                Ok(c) => c,
                Err(e) => return DownloadState::Failed(e.to_string()),
            };

            // HLS playlists are fetched segment by segment; everything else is
            // a plain (resumable) file download.
            if is_hls {
                let outcome = hls_download::download_hls(
                    &client,
                    &url,
                    std::path::Path::new(&dest_path),
                    cancel_for_job,
                    move |progress| {
                        downloaded_for_report.store(progress.downloaded, Ordering::Relaxed);
                        total_for_report.store(progress.estimated_total, Ordering::Relaxed);
                        if let Ok(mut bps) = bps_for_report.lock() {
                            *bps = progress.bytes_per_second;
                        }
                    },
                )
                .await;
                return match outcome {
                    Ok(HlsOutcome::Completed { .. }) => DownloadState::Completed,
                    Ok(HlsOutcome::Cancelled { .. }) => DownloadState::Cancelled,
                    Err(message) => DownloadState::Failed(message),
                };
            }

            match download::download(
                &client,
                &url,
                std::path::Path::new(&dest_path),
                cancel_for_job,
                move |progress| {
                    downloaded_for_report.store(progress.downloaded, Ordering::Relaxed);
                    if let Some(total) = progress.total {
                        total_for_report.store(total, Ordering::Relaxed);
                    }
                    if let Ok(mut bps) = bps_for_report.lock() {
                        *bps = progress.bytes_per_second;
                    }
                },
            )
            .await
            {
                Ok(DownloadOutcome::Completed { .. }) => DownloadState::Completed,
                Ok(DownloadOutcome::Paused { .. }) => DownloadState::Paused,
                Err(e) => DownloadState::Failed(e.user_message()),
            }
        }));
        let final_state = std::panic::catch_unwind(job)
            .unwrap_or_else(|_| DownloadState::Failed("internal error during download".to_string()));

        *lock(&handle.state) = final_state;
        let _ = thread_id;
    });

    to_jstring(&mut env, &id)
}

/// JNI: Engine.nativeDownloadStatus(id) ->
/// JSON { state: "running"|"completed"|"paused"|"cancelled"|"failed", downloaded, total, bytes_per_second, error? }
#[unsafe(no_mangle)]
pub extern "system" fn Java_com_aniciel_app_Engine_nativeDownloadStatus<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    id: JString<'local>,
) -> jstring {
    let id: String = match env.get_string(&id) {
        Ok(s) => s.into(),
        Err(_) => return to_jstring(&mut env, &error_json("invalid id string")),
    };

    let reg = lock(registry());
    let json = match reg.get(&id) {
        Some(handle) => {
            let downloaded = handle.downloaded.load(Ordering::Relaxed);
            let total = handle.total.load(Ordering::Relaxed);
            let bps = handle.bytes_per_second.lock().map(|v| *v).unwrap_or(0.0);
            let state = lock(&handle.state).clone();
            let (state_str, error) = match state {
                DownloadState::Running => ("running", None),
                DownloadState::Completed => ("completed", None),
                DownloadState::Paused => ("paused", None),
                DownloadState::Cancelled => ("cancelled", None),
                DownloadState::Failed(msg) => ("failed", Some(msg)),
            };
            let mut obj = serde_json::json!({
                "state": state_str,
                "downloaded": downloaded,
                "total": total,
                "bytes_per_second": bps,
            });
            if let Some(msg) = error {
                obj["error"] = serde_json::Value::String(msg);
            }
            obj.to_string()
        }
        None => error_json("unknown download id"),
    };

    to_jstring(&mut env, &json)
}

/// JNI: Engine.nativeCancelDownload(id) -> "true"/"false"
#[unsafe(no_mangle)]
pub extern "system" fn Java_com_aniciel_app_Engine_nativeCancelDownload<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    id: JString<'local>,
) -> jstring {
    let id: String = match env.get_string(&id) {
        Ok(s) => s.into(),
        Err(_) => return to_jstring(&mut env, "false"),
    };
    let reg = lock(registry());
    let found = if let Some(handle) = reg.get(&id) {
        handle.cancel.store(true, Ordering::Relaxed);
        true
    } else {
        false
    };
    to_jstring(&mut env, if found { "true" } else { "false" })
}

// ---------------------------------------------------------------------
// Init, homepage feed, favorites
// ---------------------------------------------------------------------

use crate::favorites::{FavoriteItem, FavoritesManager};

/// JNI: Engine.nativeInit(dataDir) -- call once at app startup, before any
/// other Engine.* call. Points the vendored engine's on-disk state
/// (favorites.json, history, cache) at the app's own private storage via
/// the MOVIEBOX_DATA_DIR / MOVIEBOX_CONFIG_DIR overrides it already
/// supports (see config.rs), instead of the Linux XDG dirs it'd otherwise
/// try to resolve via the `dirs` crate.
#[unsafe(no_mangle)]
pub extern "system" fn Java_com_aniciel_app_Engine_nativeInit<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    data_dir: JString<'local>,
) {
    let data_dir: String = match env.get_string(&data_dir) {
        Ok(s) => s.into(),
        Err(_) => return,
    };
    // Safety: called once, synchronously, at startup before any other
    // Engine.* call spawns threads that might read these vars.
    unsafe {
        std::env::set_var("MOVIEBOX_DATA_DIR", &data_dir);
        std::env::set_var("MOVIEBOX_CONFIG_DIR", &data_dir);
    }
}

/// JNI: Engine.nativeHomepage(tabId, page) -> JSON array of CatalogItem
/// tabId "2" matches the TUI's own default ("trending"-equivalent) tab.
/// MovieBox-only: the other providers are scrapers without a browsable
/// trending/homepage endpoint of their own.
#[unsafe(no_mangle)]
pub extern "system" fn Java_com_aniciel_app_Engine_nativeHomepage<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    tab_id: JString<'local>,
    page: jint,
) -> jstring {
    let tab_id: String = match env.get_string(&tab_id) {
        Ok(s) => s.into(),
        Err(_) => return to_jstring(&mut env, &error_json("invalid tabId string")),
    };

    let json = guarded(|| {
        let result = runtime().block_on(async {
            let service = MovieBoxService::new();
            service.homepage(&tab_id, page.max(1) as usize).await
        });

        match result {
            Ok((items, _metrics)) => serde_json::to_string(&items).unwrap_or_else(|_| "[]".to_string()),
            Err(e) => error_json(&e),
        }
    });

    to_jstring(&mut env, &json)
}

/// JNI: Engine.nativeFavoritesList() -> JSON array of FavoriteItem
#[unsafe(no_mangle)]
pub extern "system" fn Java_com_aniciel_app_Engine_nativeFavoritesList<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
) -> jstring {
    let manager = FavoritesManager::new();
    let json = serde_json::to_string(&manager.items).unwrap_or_else(|_| "[]".to_string());
    to_jstring(&mut env, &json)
}

/// JNI: Engine.nativeFavoritesToggle(subjectId, provider) ->
/// JSON { "is_favorite": bool } or {"error": ...}
/// Re-fetches details for subjectId to build the FavoriteItem -- keeps the
/// call self-contained (no need to shuttle a MediaDetails JSON blob back
/// in from Kotlin) at the cost of one extra network round trip, which is
/// fine for an infrequent action like toggling a favorite.
#[unsafe(no_mangle)]
pub extern "system" fn Java_com_aniciel_app_Engine_nativeFavoritesToggle<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    subject_id: JString<'local>,
    provider: JString<'local>,
) -> jstring {
    let subject_id: String = match env.get_string(&subject_id) {
        Ok(s) => s.into(),
        Err(_) => return to_jstring(&mut env, &error_json("invalid subjectId string")),
    };
    let provider_str_in: String = env
        .get_string(&provider)
        .map(|s| s.into())
        .unwrap_or_default();

    // AniDB.app is a sidecar provider (not a ProviderKind). FavoriteItem
    // stores its provider as a plain string, so build the item directly
    // from the details JSON.
    if provider_str_in == anidbapp::PROVIDER_ID {
        let json = guarded(|| {
            match runtime().block_on(AniDbAppClient::new().details(&subject_id)) {
                Ok(d) => {
                    let item = FavoriteItem {
                        provider: anidbapp::PROVIDER_ID.to_string(),
                        subject_id: subject_id.clone(),
                        title: d["title"].as_str().unwrap_or("Unknown").to_string(),
                        cover_url: d["poster_url"].as_str().map(str::to_string),
                        stype: 2,
                        release_year: d["year"].as_str().unwrap_or("").to_string(),
                        added_at: std::time::SystemTime::now()
                            .duration_since(std::time::UNIX_EPOCH)
                            .map(|t| t.as_secs())
                            .unwrap_or(0),
                    };
                    let mut manager = FavoritesManager::new();
                    let now_favorited = manager.toggle(item);
                    format!("{{\"is_favorite\":{now_favorited}}}")
                }
                Err(e) => error_json(&e),
            }
        });
        return to_jstring(&mut env, &json);
    }

    let provider_kind = match parse_provider(&provider_str_in) {
        Some(p) => p,
        None => return to_jstring(&mut env, &error_json("unknown provider")),
    };

    let result = runtime().block_on(async {
        let service = MovieBoxService::new();
        service.details_typed(provider_kind, &subject_id).await
    });

    let json = match result {
        Ok(details) => {
            let item = FavoriteItem::from_details(&provider_str(provider_kind), &details);
            let mut manager = FavoritesManager::new();
            let now_favorited = manager.toggle(item);
            format!("{{\"is_favorite\":{now_favorited}}}")
        }
        Err(e) => error_json(&e.to_string()),
    };

    to_jstring(&mut env, &json)
}


/// JNI: Engine.nativeChapterPages(chapterId) -> JSON string array of page image URLs
#[unsafe(no_mangle)]
pub extern "system" fn Java_com_aniciel_app_Engine_nativeChapterPages<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    chapter_id: JString<'local>,
) -> jstring {
    let chapter_id: String = match env.get_string(&chapter_id) {
        Ok(s) => s.into(),
        Err(_) => return to_jstring(&mut env, &error_json("invalid chapter id")),
    };
    let json = guarded(|| {
        let result = runtime().block_on(async {
            let client = crate::providers::mangadex::MangaDexClient::new();
            client.chapter_pages(&chapter_id).await
        });
        match result {
            Ok(pages) => serde_json::to_string(&pages).unwrap_or_else(|_| "[]".to_string()),
            Err(e) => error_json(&e.to_string()),
        }
    });
    to_jstring(&mut env, &json)
}
