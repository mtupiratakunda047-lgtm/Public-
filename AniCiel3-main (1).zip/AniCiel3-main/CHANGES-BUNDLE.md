# AniCiel full fix bundle (hub filter → manga offline)

## UI / navigation
- Per-tab filters: Movies / Anime / Manga / Adult (PlatformHome)
- Adult age gate; Adult tab adult-only when tagged
- Downloads FAB on all main screens
- Episode long-press (~2s) multi-select
- Download progress: size, speed, ETA (where possible)

## Downloads
- Public folder: /storage/emulated/0/AniCiel/Downloads (and Manga/)
- DASH meta ENOENT fix; invalid 0000-0000 storage fallback
- Faster parallel HLS (batch 12) + 4 concurrent jobs

## Manga
- MangaDex engine provider (search, chapters, pages)
- JNI Engine.chapterPages + Kotlin API
- Details: open chapter in MangaReaderActivity
- Offline: download pages to AniCiel/Manga/<title>/<chapter>/

## Internet Archive
- Engine provider (search, details, file list)
- Details: list mp4/mkv/pdf/cbz files + queue download

## Sources registry
- mangadex ACTIVE, internetarchive ACTIVE
