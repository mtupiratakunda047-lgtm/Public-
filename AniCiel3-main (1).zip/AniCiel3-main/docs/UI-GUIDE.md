# AniCiel UI Guide (platform direction)

Visual identity: black background, cyan/blue accent (`#29B6F6`), AniCiel wordmark top-left.

## Hierarchy
1. Header: **AniCiel** + toolbar (Sources, Settings, Library, Updates, Extensions, Favorites, Downloads)
2. Search: full-width across enabled sources
3. Bottom nav: **Movies | Anime | Manga | Adult**
4. Feeds: Featured / Trending / Recently Added / Recommended / Continue Watching|Reading
5. Card → Details → Player (video) or Reader (manga)

## Adult
- Selecting **Adult** shows age gate first: “Are you 18 years old or older?”
- YES → unlock + enter section; NO → stay out; no adult previews before confirm
- Preference: `AppPreferences.adultEnabled`

## Backend reality (0.5.1)
- Movies/Anime: Engine providers (MovieBox, etc.) + ExoPlayer
- Manga: reader exists; source download not implemented (REFERENCE sources only)
- Adult: UI category + gate; dedicated adult sources not fully wired

Evolve the existing Compose screens toward the MediaHub mockups without renaming the app.
