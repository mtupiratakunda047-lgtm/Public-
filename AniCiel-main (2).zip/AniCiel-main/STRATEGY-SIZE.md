# Storage-efficient cloning strategy (Anikku → AniCiel)

Anikku source ZIP ≈ **8.1 MB** compressed / ~23 MB uncompressed.
AniCiel target: **under 25 MB** ZIP (currently ~3.3 MB → plenty of headroom).

## Why Anikku stays small as source but heavy as APK
| Anikku bloat | Size driver | AniCiel approach |
|--------------|-------------|------------------|
| baseline-prof.txt | ~3.9 MB | Omit |
| Multi-language i18n | many × 90–110 KB | English only |
| Widget preview webp | ~420 KB | No widgets |
| README screenshots | ~1 MB | Omit |
| Extension system + deps | large APK at runtime | Engine providers + SourceRegistry only |
| mpv native .so | multi-MB per ABI | Media3 only (same online/offline UI) |

## Feature cloning map (light clones)

| Feature | Heavy Anikku way | Light AniCiel way |
|---------|------------------|-------------------|
| Multi-source | Extension APKs | SourceRegistry + Engine READY providers |
| Library categories | SQLDelight/Room modules | LibraryStore JSON + LibraryScreen |
| Trackers OAuth | Full API clients | Trackers.kt open search + local IDs |
| mpv player | Native binaries | Shared Media3 player online+offline |
| Updates tab | Complex work manager | UpdatesScreen + Engine.details refresh |
| Migration | Full source migrate UI | LibraryStore.migrate + dialog |
| Merge | Domain interactors | LibraryStore.merge + multi-select |
| Suggestions | Per-source scrapers | SimilarSection from details |
| Widgets | presentation-widget module | Classic AppWidgetProvider + XML layouts (no Glance, no preview WebP) |
| Manga reader | Full reader stack | MangaReaderActivity pager |
| Multi-module | 15+ Gradle modules | Single app module (packages only) |
| Auto-update | Installer + signature | UpdateChecker → browser |

## Headroom
- AniCiel source ~0.7 MB on disk, ZIP ~3.3 MB
- Can grow to ~20 MB ZIP before hitting 25 MB limit
- Still avoid: baseline profiles, 30 languages, mpv .so, widget assets
