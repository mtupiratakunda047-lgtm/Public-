# AniCiel 0.3.1 — quick integration pass

## What was added / improved (kept small)

- **LibraryStore.kt** — lightweight local library + Continue Watching + Favorites
  - JSON-backed, no extra dependencies
  - Inspired by history/library patterns from Tachiyomi-style apps (Anikku etc.)
  - Methods: `continueWatching()`, `favorites()`, `updateProgress()`, `toggleFavorite()`

- **AppPreferences** — added `showContinueWatching` toggle

- Version bumped to **0.3.1** (versionCode 3)

- Source registry kept honest: READY sources are real, REFERENCE sources are documented but not pretended to be live adapters

## Still intentionally not included (to keep ZIP small & honest)

- Full manga reader / page viewer
- Dozens of real Android source adapters (would bloat size and require continuous maintenance)
- Full multi-module architecture from Anikku
- Backend servers / Python APIs (they stay outside the APK)

## Size note

This release stays well under 25 MB. Large splash video and launcher assets are the main contributors; source code itself is tiny.

## How to use the new LibraryStore

In `MainActivity` or `PlayerActivity` after init:

```kotlin
LibraryStore.init(context)

// When user watches something:
LibraryStore.updateProgress(
    key = "moviebox:12345",
    title = "Title",
    posterUrl = "...",
    category = "Anime",
    season = 1,
    episode = 3,
    positionMs = player.currentPosition,
    durationMs = player.duration
)

// Show continue watching:
val continueList = LibraryStore.continueWatching(12)
```
