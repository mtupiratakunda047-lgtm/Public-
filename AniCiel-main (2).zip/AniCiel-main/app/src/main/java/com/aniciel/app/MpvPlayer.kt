package com.aniciel.app

import android.content.Context
import android.view.ViewGroup
import android.widget.FrameLayout
import `is`.xyz.mpv.BaseMPVView
import `is`.xyz.mpv.MPVLib

/**
 * Thin mpv backend (Aniyomi-style). Native .so files come from
 * io.github.secozzi:mpv-android-lib at Gradle build time — not in the source ZIP.
 *
 * Falls back gracefully if the library is missing at runtime.
 */
class MpvPlayerView(context: Context) : BaseMPVView(context, null) {
    init {
        layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
    }

    fun load(url: String, headers: Map<String, String> = emptyMap()) {
        if (headers.isNotEmpty()) {
            val headerStr = headers.entries.joinToString("\r\n") { "${it.key}: ${it.value}" } + "\r\n"
            MPVLib.setOptionString("http-header-fields", headerStr)
        }
        MPVLib.command(arrayOf("loadfile", url, "replace"))
    }

    fun play() = MPVLib.command(arrayOf("set", "pause", "no"))
    fun pause() = MPVLib.command(arrayOf("set", "pause", "yes"))
    fun seekTo(seconds: Double) = MPVLib.command(arrayOf("seek", seconds.toString(), "absolute"))
    fun seekBy(seconds: Double) = MPVLib.command(arrayOf("seek", seconds.toString(), "relative"))

    fun isPaused(): Boolean = try {
        MPVLib.getPropertyBoolean("pause")
    } catch (_: Exception) {
        true
    }

    fun positionSeconds(): Double = try {
        MPVLib.getPropertyDouble("time-pos") ?: 0.0
    } catch (_: Exception) {
        0.0
    }

    fun durationSeconds(): Double = try {
        MPVLib.getPropertyDouble("duration") ?: 0.0
    } catch (_: Exception) {
        0.0
    }
}

object PlayerBackend {
    const val EXO = "exo"
    const val MPV = "mpv"
}
