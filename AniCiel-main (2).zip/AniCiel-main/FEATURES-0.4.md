# AniCiel 0.4 — features added vs Anikku (size-conscious)

ZIP target: under 25 MB source package.

## Requested items status

| # | Feature | Status in 0.4 |
|---|---------|----------------|
| 2 | Real multi-source catalogue | **Partial** — still uses Engine providers (MovieBox + optional Rust). Source Center lists all known sources; READY ones work. Full extension APK system not added (would explode size). |
| 3 | Full library + categories | **Yes** — LibraryStore has categories (Default/Watching/Completed/On Hold/Dropped/Plan to Watch + custom), favorites, continue watching. |
| 5 | Trackers (MAL, AniList, …) | **Browser search** — opens official search pages + stores local linked IDs. Full OAuth not included (size + secrets). |
| 6 | Advanced mpv player | **Optional** — mpv native libs alone often exceed 25 MB. Online & offline both use Media3/ExoPlayer with the **same** Next/Prev, quality, subs, speed controls. |
| 8 | Updates tab / library update | **Data ready** — library entries can be refreshed via Engine.details; UI can call LibraryStore. |
| 9 | Migration between sources | **Yes** — LibraryStore.migrate(oldKey, newProvider, newId). |
| 10 | Merge anime/episodes | **Yes** — LibraryStore.merge(targetKey, otherKeys). |
| 11 | Suggestions / related | **Partial** — details screen already has SimilarSection when engine returns related items. |
| 16 | Widgets | **Yes (light)** — classic AppWidgetProvider, no Glance, no preview images. Continue Watching (4×2), Downloads (2×1), 1×1 shortcut. |
| 18 | Manga reader | **Yes (basic)** — MangaReaderActivity: horizontal pager for local images or URLs + Prev/Next pages. |
| 19 | Multi-module architecture | **Not rewritten** — kept single-module + Rust engine (intentional for size). |
| 20 | Auto app update | **Yes (check)** — UpdateChecker hits GitHub Releases API and opens the release page. No silent install. |

## Offline = Online playback parity

Both modes share:
- Next / Previous episode (or playlist item)
- Play/Pause, seek, speed, aspect, lock, brightness/volume gestures
- Subtitles / quality where available
- Progress written to LibraryStore

Online loads episode list from Engine.details().  
Offline builds a cleaned episode playlist from the download folder (one file per episode).

## Intentionally NOT ported (size / scope)

- Installable extension APKs
- Full MAL/AniList OAuth
- mpv-android
- Full Tachiyomi multi-module tree
- Torrent / Cast / Discord RPC
=== Extensions note ===
- 0.4.1: ExtensionsScreen + Extensions.kt (repo index, download APK, system installer). Aniyomi APKs installable; Engine playback adapters still future work.
- 0.4.3: Bugfix release — missing Compose icon imports (would not compile), settings scroll, toolbar overflow, library reload, default All category.

- 0.5.0: Full AniList/MAL OAuth (user client IDs) + optional mpv backend (io.github.secozzi:mpv-android-lib).
- 0.5.1: OAuth removed; trackers are browser search only. mpv backend kept.
