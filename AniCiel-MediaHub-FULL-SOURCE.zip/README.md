# AniCiel MediaHub NEW

Fresh AniCiel from **MediaHub images + Google Drive base.apk only**.

Not the Netplay tree. No VIP, coins, tokens, ads, or sign-in.

## Includes (91 APIs)
All base.apk wefeed paths except money/vip/ad/activity/fission/login.

Core streaming: play-info, resource, search, trending, captions, download start/finish, tab-operating, …

## Layout
- `sources/` — allowed + excluded path lists from base.apk
- `engine/.../paths.rs` — Rust constants
- `app/.../MovieBoxApi.kt` — Kotlin constants
- MediaHub theme, nav, adult gate, public downloads

## Apply
See APPLY.md — use on a **clean** project, not Netplay-patched AniCiel-main.
