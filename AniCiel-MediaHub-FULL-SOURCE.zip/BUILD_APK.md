# Build APK via GitHub Actions (no SDK here)
git push → Actions → download APK artifact
