# AniCiel DASH download fix

Updated `Downloader.kt` to detect MPEG-DASH (`.mpd` / `application/dash+xml`) sources instead of treating the MPD XML manifest as a video file.

Implemented:
- DASH/MPD detection, including extension-less signed URLs.
- SegmentTemplate + SegmentTimeline parsing.
- `$RepresentationID$`, `$Number$`, `$Time$`, `$Bandwidth$` substitutions.
- Zero-padded `$Number%05d$` / `$Time%05d$` templates.
- Parallel DASH segment downloading with resume metadata.
- Separate clear video/audio representation download and Android `MediaExtractor`/`MediaMuxer` remuxing.
- Existing plain-file and HLS paths retained.
- DASH DRM/ContentProtection is intentionally not bypassed.

Note: this archive contains the updated source file from the supplied archive, not a complete Gradle project, so an APK cannot be built from this archive alone.
