"""Extended functionalities module"""
