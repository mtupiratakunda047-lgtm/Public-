from moviebox_api_v3.v1.cli.interface import main

main()
