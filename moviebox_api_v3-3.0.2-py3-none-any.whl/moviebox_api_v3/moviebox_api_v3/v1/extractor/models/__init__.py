"""Models for the extracted item details"""

from moviebox_api_v3.v1.extractor.models.json import ItemJsonDetailsModel
from moviebox_api_v3.v1.extractor.models.tag import ItemTagDetailsModel

__all__ = ["ItemJsonDetailsModel", "ItemTagDetailsModel"]
