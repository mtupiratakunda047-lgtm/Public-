"""v2 Exceptions"""

from moviebox_api_v3.v1.exceptions import (
    ExhaustedSearchResultsError,
    MovieboxApiException,
)


class InvalidDetailPathError(MovieboxApiException): ...
