import sys

from moviebox_api_v3.console import cli_entry

sys.exit(cli_entry())
