from moviebox_api_v3.v1.exceptions import (
    ExhaustedSearchResultsError,
    MovieboxApiException,
    ZeroCaptionFileError,
    ZeroMediaFileError,
    ZeroSearchResultsError,
)


class ResultsNavigationError(MovieboxApiException): ...


class MissingDubError(MovieboxApiException): ...
