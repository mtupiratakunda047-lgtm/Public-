from importlib import metadata

try:
    __version__ = metadata.version("moviebox_api_v3")
except metadata.PackageNotFoundError:
    __version__ = "3.0.1"

__author__ = "BotMada"
__repo__ = "https://pypi.org/project/moviebox-api-v3/"
