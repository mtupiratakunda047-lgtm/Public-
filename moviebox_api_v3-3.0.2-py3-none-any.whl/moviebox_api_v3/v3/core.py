from __future__ import annotations
from collections.abc import AsyncIterator
from typing import Any

from moviebox_api_v3.v3._bases import BaseContentProviderAndHelper
from moviebox_api_v3.v3.constants import (
    MOVIEBOX_AUTO_FRENCH_DUB,
    MOVIEBOX_VF_ENRICH_LIMIT,
    RESULTS_PER_PAGE_AMOUNT,
    CustomResolutionType,
    ResolutionType,
    SubjectType,
    TabID,
)
from moviebox_api_v3.v3.exceptions import (
    ExhaustedSearchResultsError,
    ResultsNavigationError,
    ZeroSearchResultsError,
)
from moviebox_api_v3.v3.helpers import (
    assert_instance,
    is_valid_search_item,
    sanitize_item_name,
    sort_search_items_for_preferred_language,
    validate_per_page_and_raise,
    validate_subject_id,
)
from moviebox_api_v3.v3.http_client import MovieBoxHttpClient
# Pydantic models are imported lazily inside get_content_model* helpers.
# This keeps the raw API client installable on platforms without pydantic-core wheels
# such as Android/Pydroid.
from moviebox_api_v3.v3.urls import (
    EXT_CAPTIONS_PATH,
    MAIN_PAGE_PATH,
    RESOURCE_PATH,
    SEARCH_PATH,
    SEARCH_PATH_V2,
    SEASON_INFO_PATH,
    SUBJECT_GET_PATH,
)



def _is_video_file_metadata(resource: object) -> bool:
    try:
        from moviebox_api_v3.v3.models.downloadables import VideoFileMetadata
    except Exception:
        return False
    return isinstance(resource, VideoFileMetadata)

# ---------------------------------------------------------------------------
# French VF localization helpers
# ---------------------------------------------------------------------------

_FRENCH_DUB_ALIASES = {
    "fr",
    "fra",
    "fre",
    "fr-fr",
    "fr-mg",
    "french",
    "francais",
    "français",
    "vf",
    "v.f",
    "v.f.",
    "vff",
    "version francaise",
    "version française",
}


def _norm_lang(value: object) -> str:
    if value is None:
        return ""
    return str(value).strip().lower().replace("_", "-").replace(".", "")


def _is_french_dub(dub: dict | object) -> bool:
    if isinstance(dub, dict):
        code = _norm_lang(dub.get("lanCode") or dub.get("code"))
        name = _norm_lang(dub.get("lanName") or dub.get("language") or dub.get("name"))
    else:
        code = _norm_lang(getattr(dub, "lan_code", None) or getattr(dub, "lanCode", None))
        name = _norm_lang(getattr(dub, "lan_name", None) or getattr(dub, "lanName", None))

    if code in _FRENCH_DUB_ALIASES:
        return True
    return any(alias in name for alias in _FRENCH_DUB_ALIASES)


def _find_french_dub(dubs: list | None) -> dict | None:
    if not isinstance(dubs, list):
        return None
    for dub in dubs:
        if isinstance(dub, dict) and _is_french_dub(dub):
            return dub
    return None


def _subject_id_from_item(item: dict) -> str | None:
    for key in ("subjectId", "id", "_id", "objectId", "postId"):
        value = item.get(key)
        if isinstance(value, (str, int)) and str(value):
            return str(value)
        if isinstance(value, dict):
            for sub in ("$oid", "oid", "id", "subjectId"):
                if value.get(sub):
                    return str(value[sub])
    return None


def _merge_localized_details_into_item(item: dict, details: dict, french_subject_id: str | None = None) -> dict:
    """Merge useful localized fields from /subject/get into a homepage/search item."""
    if french_subject_id:
        item["subjectId"] = french_subject_id
        item["preferredSubjectId"] = french_subject_id
        item["vfSubjectId"] = french_subject_id

    for key in (
        "title",
        "postTitle",
        "description",
        "cover",
        "genre",
        "releaseDate",
        "countryName",
        "language",
        "subtitles",
        "imdbRatingValue",
        "subjectType",
        "dubs",
        "duration",
        "durationSeconds",
        "hasResource",
        "seasons",
        "resourceDetectors",
    ):
        if key in details and details[key] not in (None, "", []):
            item[key] = details[key]

    item["vfAvailable"] = True
    item["preferredDub"] = "fr"
    return item


async def _fetch_details_cached(client_session: MovieBoxHttpClient, subject_id: str) -> dict | None:
    cache = getattr(client_session, "_vf_details_cache", None)
    if cache is None:
        cache = {}
        setattr(client_session, "_vf_details_cache", cache)

    if subject_id in cache:
        return cache[subject_id]

    try:
        details = await client_session.get_from_api(SUBJECT_GET_PATH, params={"subjectId": subject_id})
        cache[subject_id] = details
        return details
    except Exception:
        cache[subject_id] = None
        return None


async def _prefer_french_item(client_session: MovieBoxHttpClient, item: dict) -> dict:
    """Return the same item, but using the French dub subjectId/details when exposed by MovieBox."""
    if not MOVIEBOX_AUTO_FRENCH_DUB or not isinstance(item, dict):
        return item

    original_subject_id = _subject_id_from_item(item)
    if not original_subject_id:
        item["vfAvailable"] = False
        return item

    # First, use dubs already present in the payload.
    french_dub = _find_french_dub(item.get("dubs"))

    # If not present, fetch details once for this subject.
    original_details = None
    if french_dub is None:
        original_details = await _fetch_details_cached(client_session, original_subject_id)
        if isinstance(original_details, dict):
            french_dub = _find_french_dub(original_details.get("dubs"))
            if original_details.get("dubs"):
                item["dubs"] = original_details.get("dubs")

    if not french_dub:
        item["vfAvailable"] = False
        return item

    french_subject_id = str(french_dub.get("subjectId") or original_subject_id)

    # If the French dub points to another subject, fetch its localized details.
    french_details = None
    if french_subject_id:
        french_details = await _fetch_details_cached(client_session, french_subject_id)

    if isinstance(french_details, dict):
        return _merge_localized_details_into_item(item, french_details, french_subject_id)

    # At least expose the French ID when details cannot be fetched.
    item["subjectId"] = french_subject_id
    item["preferredSubjectId"] = french_subject_id
    item["vfSubjectId"] = french_subject_id
    item["vfAvailable"] = True
    item["preferredDub"] = "fr"
    return item


def _iter_subject_items(node: object):
    if isinstance(node, dict):
        if "subjectId" in node or "title" in node or "subjectTitle" in node or "cover" in node:
            yield node
        for value in node.values():
            if isinstance(value, (dict, list)):
                yield from _iter_subject_items(value)
    elif isinstance(node, list):
        for value in node:
            if isinstance(value, (dict, list)):
                yield from _iter_subject_items(value)


async def _prefer_french_in_payload(client_session: MovieBoxHttpClient, payload: dict, limit: int | None = None) -> dict:
    if not MOVIEBOX_AUTO_FRENCH_DUB or not isinstance(payload, dict):
        return payload

    max_items = MOVIEBOX_VF_ENRICH_LIMIT if limit is None else limit
    count = 0

    for item in _iter_subject_items(payload):
        if count >= max_items:
            break
        await _prefer_french_item(client_session, item)
        count += 1

    payload["preferredLocale"] = "fr-MG"
    payload["preferredCountry"] = "MG"
    payload["preferredDub"] = "fr"
    payload["vfEnrichedCount"] = count
    return payload


def _pick_french_subject_id_from_details(details: dict, fallback_subject_id: str) -> str:
    french_dub = _find_french_dub(details.get("dubs") if isinstance(details, dict) else None)
    if french_dub and french_dub.get("subjectId"):
        return str(french_dub["subjectId"])
    return fallback_subject_id



class Homepage(BaseContentProviderAndHelper):
    """Fetches landing page contents"""

    # TODO: Add page navigation

    _path = MAIN_PAGE_PATH

    def __init__(self, client_session: MovieBoxHttpClient):
        """Constructor for `Homepage`"""
        self.client_session = client_session
        self._page_number: int = 1
        self._tab_id: int | TabID = 0
        self._version: str = ""

    def __setattr__(self, name, value):
        match name:
            case "client_session":
                assert_instance(value, MovieBoxHttpClient, "client_session")

            case "_per_page":
                validate_per_page_and_raise(value)

            case "_tab_id":
                assert_instance(value, (TabID, int), "tab_id")

            case _:
                pass

        super().__setattr__(name, value)

    def _create_params(self) -> dict:
        return {
            "page": self._page_number,
            "tabId": self._tab_id,
            "version": self._version,
        }

    async def get_content(self) -> dict:
        payload = self._create_params()
        contents = await self.client_session.get_from_api(
            self._path, params=payload
        )
        # Homepage stays raw-safe to avoid MovieBox homepage instability.
        # Search/details/resources still use VF enrichment.
        return contents

    async def get_content_model(self, *args, **kwargs) -> RootHomepageModel:
        content = await self.get_content(*args, **kwargs)
        from moviebox_api_v3.v3.models.homepage import RootHomepageModel
        return RootHomepageModel.model_validate(content)


class Search(BaseContentProviderAndHelper):
    """Performs a search of movies, tv series, music  etc or both"""

    _path = SEARCH_PATH

    def __init__(
        self,
        client_session: MovieBoxHttpClient,
        query: str,
        subject_type: SubjectType = SubjectType.ALL,
        page: int = 1,
        per_page: int = RESULTS_PER_PAGE_AMOUNT,
    ):

        self.client_session = client_session
        self._subject_type = subject_type
        self._query = query
        self._page = page
        self._per_page = per_page

    def __setattr__(self, name, value):
        match name:
            case "client_session":
                assert_instance(value, MovieBoxHttpClient, "client_session")

            case "_per_page":
                validate_per_page_and_raise(value)

            case "_subject_type":
                assert_instance(value, SubjectType, "_subject_type")

            case _:
                pass

        super().__setattr__(name, value)

    def _create_payload(self) -> dict[str, str | int]:
        """Creates payload from the parameters declared.

        Returns:
            dict[str, str|int]: Ready payload
        """

        return {
            "keyword": self._query,
            "page": self._page,
            "perPage": self._per_page,
            "subjectType": self._subject_type.value,
        }

    async def get_content(self) -> dict:
        """Performs the actual fetch of contents

        Returns:
            dict: Fetched results
        """
        contents = await self.client_session.post_to_api(
            self._path, json=self._create_payload()
        )

        if self._subject_type is not SubjectType.ALL:
            # Sometimes server response include irrelevant
            # items

            target_items = []

            for item in contents["items"]:
                if item["subjectType"] == self._subject_type.value:
                    # https://github.com/Simatwa/moviebox-api-v3/issues/55
                    item_name = item["title"]

                    if is_valid_search_item(item_name):
                        item["title"] = sanitize_item_name(item_name)
                        target_items.append(item)

            contents["items"] = sort_search_items_for_preferred_language(
                target_items, self._query
            )

            if not target_items:
                raise ZeroSearchResultsError(
                    "Search yielded empty results. Try a different keyword."
                )

        if self._subject_type is SubjectType.ALL and "items" in contents:
            contents["items"] = sort_search_items_for_preferred_language(
                contents["items"], self._query
            )

        if "items" in contents and isinstance(contents["items"], list):
            enriched_items = []
            for item in contents["items"]:
                enriched_items.append(await _prefer_french_item(self.client_session, item))
            contents["items"] = sort_search_items_for_preferred_language(
                enriched_items, self._query
            )
            contents["preferredLocale"] = "fr-MG"
            contents["preferredCountry"] = "MG"
            contents["preferredDub"] = "fr"

        return contents

    async def get_content_model(self) -> RootSearchResultsModel:
        """Modelled version of the contents.

        Returns:
            RootSearchResultsModel: Modelled contents
        """
        contents = await self.get_content()
        from moviebox_api_v3.v3.models.search import RootSearchResultsModel
        return RootSearchResultsModel.model_validate(contents)

    def next_page(self, content: RootSearchResultsModel) -> "Search":
        """Navigate to the search results of the next page.

        Args:
            content (RootSearchResultsModel): Modelled version of search results

        Returns:
            Search
        """
        from moviebox_api_v3.v3.models.search import RootSearchResultsModel
        assert_instance(content, RootSearchResultsModel, "content")

        if content.pager.has_more:
            return Search(
                client_session=self.client_session,
                query=self._query,
                subject_type=self._subject_type,
                page=content.pager.next_page,
                per_page=self._per_page,
            )
        else:
            raise ExhaustedSearchResultsError(
                content.pager,
                "You have already reached the last page of the search results.",
            )

    def previous_page(self, content: RootSearchResultsModel) -> "Search":
        """Navigate to the search results of the previous page.

        - Useful when the currrent page is greater than  1.

        Args:
            content (RootSearchResultsModel): Modelled version of search results

        Returns:
            Search
        """
        from moviebox_api_v3.v3.models.search import RootSearchResultsModel
        assert_instance(content, RootSearchResultsModel, "content")

        if content.pager.page >= 2:
            return Search(
                client_session=self.client_session,
                query=self._query,
                subject_type=self._subject_type,
                page=content.pager.page - 1,
                per_page=self._per_page,
            )

        else:
            raise ResultsNavigationError(
                "Unable to navigate to previous page. "
                "Current page is the first one, try navigating to the next "
                "one instead."
            )

    async def get_content_model_all(
        self,
    ) -> AsyncIterator[RootSearchResultsModel]:

        navigating = True

        cursor = self

        while navigating:
            content_model = await cursor.get_content_model()

            yield content_model

            if content_model.pager.has_more:
                cursor = cursor.next_page(content_model)

            else:
                navigating = False


class SearchV2(BaseContentProviderAndHelper):
    """Performs a search of movies, tv series, music  etc or both"""

    _path = SEARCH_PATH_V2

    def __init__(
        self,
        client_session: MovieBoxHttpClient,
        query: str,
        subject_type: SubjectType = SubjectType.ALL,
        tab_id: TabID = TabID.ALL,
        page: int = 1,
        per_page: int = RESULTS_PER_PAGE_AMOUNT,
    ):

        self.client_session = client_session
        self._subject_type = subject_type
        self._query = query
        self._page = page
        self._per_page = per_page
        self._tab_id = tab_id

    def __setattr__(self, name, value):
        match name:
            case "client_session":
                assert_instance(value, MovieBoxHttpClient, "client_session")

            case "_per_page":
                validate_per_page_and_raise(value)

            case "_tab_id":
                assert_instance(value, TabID, "tab_id")

            case "_subject_type":
                assert_instance(value, SubjectType, "subjct_type")

            case _:
                pass

        super().__setattr__(name, value)

    def _create_payload(self) -> dict[str, str | int]:
        """Creates payload from the parameters declared.

        Returns:
            dict[str, str|int]: Ready payload
        """

        return {
            "keyword": self._query,
            "page": self._page,
            "perPage": self._per_page,
            "subjectType": self._subject_type.value,
            "tabId": self._tab_id,
        }

    async def get_content(self) -> dict:
        """Performs the actual fetch of contents

        Returns:
            dict: Fetched results
        """
        contents = await self.client_session.post_to_api(
            self._path, json=self._create_payload()
        )

        target_items = []

        search_results = contents["results"][0]

        if self._subject_type is not SubjectType.ALL:
            # Sometimes server response include irrelevant
            # items

            for item in search_results["subjects"]:
                if item["subjectType"] == self._subject_type.value:
                    # https://github.com/Simatwa/moviebox-api-v3/issues/55
                    item_name = item["title"]

                    if is_valid_search_item(item_name):
                        item["title"] = sanitize_item_name(item_name)
                        target_items.append(item)
        else:
            target_items = search_results["subjects"]

        if isinstance(target_items, list):
            target_items = sort_search_items_for_preferred_language(
                target_items, self._query
            )

        contents["items"] = target_items

        if not target_items:
            raise ZeroSearchResultsError(
                "Search yielded empty results. Try a different keyword."
            )

        if "items" in contents and isinstance(contents["items"], list):
            enriched_items = []
            for item in contents["items"]:
                enriched_items.append(await _prefer_french_item(self.client_session, item))
            contents["items"] = sort_search_items_for_preferred_language(
                enriched_items, self._query
            )
            contents["preferredLocale"] = "fr-MG"
            contents["preferredCountry"] = "MG"
            contents["preferredDub"] = "fr"

        return contents

    async def get_content_model(self) -> RootSearchResultsModelV2:
        """Modelled version of the contents.

        Returns:
            RootSearchResultsModelV2: Modelled contents
        """
        contents = await self.get_content()
        from moviebox_api_v3.v3.models.search import RootSearchResultsModelV2
        return RootSearchResultsModelV2.model_validate(contents)

    def next_page(self, content: RootSearchResultsModelV2) -> "SearchV2":
        """Navigate to the search results of the next page.

        Args:
            content (RootSearchResultsModelV2): Modelled version of search results

        Returns:
            SearchV2
        """
        from moviebox_api_v3.v3.models.search import RootSearchResultsModelV2
        assert_instance(content, RootSearchResultsModelV2, "content")

        if content.pager.has_more:
            return SearchV2(
                client_session=self.client_session,
                query=self._query,
                subject_type=self._subject_type,
                tab_id=self._tab_id,
                page=content.pager.next_page,
                per_page=self._per_page,
            )
        else:
            raise ExhaustedSearchResultsError(
                content.pager,
                "You have already reached the last page of the search results.",
            )

    def previous_page(self, content: RootSearchResultsModelV2) -> "SearchV2":
        """Navigate to the search results of the previous page.

        - Useful when the currrent page is greater than  1.

        Args:
            content (RootSearchResultsModelV2): Modelled version of search results

        Returns:
            SearchV2
        """
        from moviebox_api_v3.v3.models.search import RootSearchResultsModelV2
        assert_instance(content, RootSearchResultsModelV2, "content")

        if content.pager.page >= 2:
            return SearchV2(
                client_session=self.client_session,
                query=self._query,
                subject_type=self._subject_type,
                tab_id=self._tab_id,
                page=content.pager.page - 1,
                per_page=self._per_page,
            )

        else:
            raise ResultsNavigationError(
                "Unable to navigate to previous page. "
                "Current page is the first one, try navigating to the next "
                "one instead."
            )

    async def get_content_model_all(
        self,
    ) -> AsyncIterator[RootSearchResultsModelV2]:

        navigating = True

        cursor = self

        while navigating:
            content_model = await cursor.get_content_model()

            yield content_model

            if content_model.pager.has_more:
                cursor = cursor.next_page(content_model)

            else:
                navigating = False


class SeasonDetails(BaseContentProviderAndHelper):
    """Fetches season information for a particular subject"""

    _path = SEASON_INFO_PATH

    def __init__(
        self,
        client_session: MovieBoxHttpClient,
    ):
        self.client_session = client_session

    def __setattr__(self, name, value):
        match name:
            case "client_session":
                assert_instance(value, MovieBoxHttpClient, "client_session")

            case _:
                pass

        super().__setattr__(name, value)

    async def get_content(self, subject_id: str) -> dict:
        if not validate_subject_id(subject_id):
            raise ValueError(f"Invalid subject id passed {subject_id!r}")

        request_params = {"subjectId": subject_id}

        contents = await self.client_session.get_from_api(
            self._path, params=request_params
        )
        return contents

    async def get_content_model(self, subject_id: str) -> SeasonsModel:
        contents = await self.get_content(subject_id)
        from moviebox_api_v3.v3.models.details import SeasonsModel
        modelled_contents = SeasonsModel.model_validate(contents)
        return modelled_contents


class ItemDetails(BaseContentProviderAndHelper):
    """Specific item details including seasons info"""

    _path = SUBJECT_GET_PATH

    def __init__(
        self, client_session: MovieBoxHttpClient, include_seasons: bool = False
    ):
        self.client_session = client_session
        self.include_seasons = include_seasons
        self.season_details = SeasonDetails(client_session)

    def __setattr__(self, name, value):
        match name:
            case "client_session":
                assert_instance(value, MovieBoxHttpClient, "client_session")

            case "season_details":
                assert_instance(value, SeasonDetails, "season_details")

            case "include_seasons":
                assert type(value) is bool, (
                    f"value for include_seasons must of {type(bool)} not "
                    f"{type(value)}"
                )

            case _:
                pass

        super().__setattr__(name, value)

    async def get_content(
        self,
        subject_id: str,
    ) -> dict:
        if not validate_subject_id(subject_id):
            raise ValueError(f"Invalid subject id passed {subject_id!r}")

        request_params = {"subjectId": subject_id}

        contents = await self.client_session.get_from_api(
            self._path, params=request_params
        )

        # If the caller gave an original/Hindi/English subject but the response exposes a
        # French dub, transparently switch to the French subject details. This makes
        # /details and downstream /resource calls behave like the MovieBox French UI.
        if MOVIEBOX_AUTO_FRENCH_DUB:
            french_subject_id = _pick_french_subject_id_from_details(contents, subject_id)
            if french_subject_id != subject_id:
                french_contents = await self.client_session.get_from_api(
                    self._path, params={"subjectId": french_subject_id}
                )
                if isinstance(french_contents, dict):
                    contents = french_contents
                    contents["originalSubjectId"] = subject_id
                    contents["preferredSubjectId"] = french_subject_id
                    contents["vfSubjectId"] = french_subject_id
                    contents["vfAvailable"] = True

        seasons = None

        if self.include_seasons:
            seasons_subject_id = str(contents.get("subjectId") or contents.get("preferredSubjectId") or subject_id)
            seasons = await self.season_details.get_content(seasons_subject_id)

        contents["seasons"] = seasons
        contents["preferredLocale"] = "fr-MG"
        contents["preferredCountry"] = "MG"
        contents["preferredDub"] = "fr"

        return contents

    async def get_content_model(
        self,
        subject_id: str,
    ) -> RootItemDetailsModel:
        contents = await self.get_content(subject_id)

        from moviebox_api_v3.v3.models.details import RootItemDetailsModel
        return RootItemDetailsModel.model_validate(contents)


class DownloadableVideoFilesDetail(BaseContentProviderAndHelper):
    """Fetches downloadable video files detail"""

    _path = RESOURCE_PATH

    def __init__(
        self,
        client_session: MovieBoxHttpClient,
        page: int = 1,
        per_page: int = RESULTS_PER_PAGE_AMOUNT,
        resolution: ResolutionType
        | CustomResolutionType = CustomResolutionType.BEST,
    ):
        self.client_session = client_session
        self.page = page
        self.per_page = per_page
        self.resolution = resolution

    def __setattr__(self, name, value):
        match name:
            case "client_session":
                assert_instance(value, MovieBoxHttpClient, "client_session")

            case "per_page":
                validate_per_page_and_raise(value)

            case "resolution":
                assert_instance(
                    value, (ResolutionType, CustomResolutionType), "resolution"
                )
                if isinstance(value, CustomResolutionType):
                    value = CustomResolutionType.convert_to_default_resolution(
                        value
                    )

            case _:
                pass

        super().__setattr__(name, value)

    def _create_params(self, subject_id: str) -> dict:
        validate_subject_id(subject_id)

        return {
            "subjectId": subject_id,
            # "se": season,
            # "ep": episode,
            "resolution": self.resolution,
            "page": self.page,
            "perPage": self.per_page,
            # "all": 0,
            # "startPosition": 1,
            # "endPosition": 1,
            # "pagerMode": 0,
            # "epFrom": 1,
            # "epTo": 1,
        }

    async def get_content(
        self, subject_id: str, release_date: str = None
    ) -> dict:

        # Resources are attached to each dub subjectId. Resolve to the French
        # subjectId first when possible.
        if MOVIEBOX_AUTO_FRENCH_DUB:
            details = await _fetch_details_cached(self.client_session, subject_id)
            if isinstance(details, dict):
                subject_id = _pick_french_subject_id_from_details(details, subject_id)

        request_params = self._create_params(subject_id)

        contents = await self.client_session.get_from_api(
            self._path,
            params=request_params,
        )
        if isinstance(contents, dict):
            contents["preferredLocale"] = "fr-MG"
            contents["preferredCountry"] = "MG"
            contents["preferredDub"] = "fr"
            contents["subjectId"] = subject_id
        if release_date:
            # this field lacks valid value so we update it after encountered
            #  from other core classes such as Search
            contents["releaseDate"] = release_date

        return contents

    async def get_content_model(
        self, subject_id: str, release_date: str = None
    ) -> RootDownloadableFilesDetailModel:
        contents = await self.get_content(subject_id, release_date)

        from moviebox_api_v3.v3.models.downloadables import RootDownloadableFilesDetailModel
        modelled_contents = RootDownloadableFilesDetailModel.model_validate(
            contents
        )
        return modelled_contents

    def next_page(
        self, content: RootDownloadableFilesDetailModel
    ) -> "DownloadableVideoFilesDetail":
        """Navigate to the search results of the next page.

        Args:
            content (RootDownloadableFilesDetailModel): Modelled version of search
                results

        Returns:
            DownloadableVideoFilesDetail
        """
        from moviebox_api_v3.v3.models.downloadables import RootDownloadableFilesDetailModel
        assert_instance(content, RootDownloadableFilesDetailModel, "content")

        if content.pager.has_more:
            return DownloadableVideoFilesDetail(
                client_session=self.client_session,
                page=content.pager.next_page,
                per_page=self.per_page,
                resolution=self.resolution,
            )
        else:
            raise ExhaustedSearchResultsError(
                content.pager,
                "You have already reached the last page of the search results.",
            )

    def previous_page(
        self, content: RootDownloadableFilesDetailModel
    ) -> "DownloadableVideoFilesDetail":
        """Navigate to the search results of the previous page.

        - Useful when the currrent page is greater than  1.

        Args:
            content (RootDownloadableFilesDetailModel): Modelled version of search
              results

        Returns:
            DownloadableVideoFilesDetail
        """
        from moviebox_api_v3.v3.models.downloadables import RootDownloadableFilesDetailModel
        assert_instance(content, RootDownloadableFilesDetailModel, "content")

        if content.pager.page >= 2:
            return DownloadableVideoFilesDetail(
                client_session=self.client_session,
                page=content.pager.page - 1,
                per_page=self.per_page,
                resolution=self.resolution,
            )

        else:
            raise ResultsNavigationError(
                "Unable to navigate to previous page. "
                "Current page is the first one, try navigating to the next "
                "one instead."
            )

    async def get_content_model_all(
        self, subject_id: str
    ) -> AsyncIterator[RootDownloadableFilesDetailModel]:

        navigating = True

        cursor = self

        while navigating:
            content_model = await cursor.get_content_model(subject_id)

            yield content_model

            if content_model.pager.has_more:
                cursor = cursor.next_page(content_model)

            else:
                navigating = False


DownloadableFilesDetail = DownloadableVideoFilesDetail


class DownloadableCaptionFileDetails(BaseContentProviderAndHelper):
    """Fetches available subtitle files detail for a particular video file"""

    _PATH = EXT_CAPTIONS_PATH

    def __init__(
        self,
        client_session: MovieBoxHttpClient,
    ):
        self.client_session = client_session

    def __setattr__(self, name, value):
        match name:
            case "client_session":
                assert_instance(value, MovieBoxHttpClient, "client_session")

            case _:
                pass

        super().__setattr__(name, value)

    def _create_params(
        self,
        subject_id: str,
        resource: VideoFileMetadata | str,
    ) -> dict[str, str]:

        validate_subject_id(subject_id)

        return {
            "subjectId": subject_id,
            "resourceId": (
                resource.resource_id
                if isinstance(resource, VideoFileMetadata)
                else resource
            ),
        }

    async def get_content(
        self,
        subject_id: str,
        resource: VideoFileMetadata | str,
    ) -> dict[str, Any]:

        request_params = self._create_params(subject_id, resource)

        resp = await self.client_session.get_from_api(
            self._PATH, params=request_params
        )

        return resp

    async def get_content_model(
        self,
        subject_id: str,
        resource: VideoFileMetadata | str,
    ) -> RootCaptionFileMetadata:
        content = await self.get_content(subject_id, resource)
        from moviebox_api_v3.v3.models.downloadables import RootCaptionFileMetadata
        return RootCaptionFileMetadata.model_validate(content)


# homepage raw-safe enabled
