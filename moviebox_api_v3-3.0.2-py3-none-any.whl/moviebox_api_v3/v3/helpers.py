import re
from dataclasses import dataclass, field
from math import ceil, floor
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

from moviebox_api_v3.v1.helpers import (
    assert_instance,
    get_event_loop,
    get_file_extension,
    is_valid_search_item,
    process_api_response,
    sanitize_item_name,
)
from moviebox_api_v3.v3.constants import (
    DEFAULT_DUB_LANGUAGE_NAME_OR_CODE,
    SEARCH_PER_PAGE_LIMIT,
    VALID_SUBJECT_ID_PATTERN,
)
from moviebox_api_v3.v3.exceptions import MissingDubError
from moviebox_api_v3.v3.models.details import (
    DubModel,
    RootItemDetailsModel,
    SeasonItemModel,
)


def combine_url_path_with_params(path: str, params: dict):
    parsed = urlparse(path)

    existing_params = dict(parse_qsl(parsed.query))

    merged_params = {**existing_params, **params}
    new_query = urlencode(merged_params)

    return urlunparse(parsed._replace(query=new_query))


def validate_subject_id(subject_id: str) -> bool:
    return VALID_SUBJECT_ID_PATTERN.match(subject_id) is not None


def validate_per_page_and_raise(per_page: int) -> None:
    assert 0 < per_page <= SEARCH_PER_PAGE_LIMIT, (
        f"per_page value {per_page} is NOT between 0 and {SEARCH_PER_PAGE_LIMIT}"
    )


@dataclass
class RequestParams:
    offset: int
    page: int
    per_page: int  # max - 20
    limit: int


@dataclass
class PaginationDetails:
    total_episodes: int
    request_params: list[RequestParams]


def get_episodes_amount(seasons: list[SeasonItemModel]) -> int:
    return sum(season.total_episodes for season in seasons)


def get_download_tv_series_request_params(
    seasons: list[SeasonItemModel],
    episode: int = 1,
    season: int = 1,
    per_page: int = 20,
    limit: int = -1,
) -> PaginationDetails:
    params: list[RequestParams] = []

    season_numbers = [s.season_number for s in seasons]

    if season not in season_numbers:
        raise ValueError(
            f"Season {season} does not exist. Available seasons: {season_numbers}"
        )

    target_season = next(s for s in seasons if s.season_number == season)
    if episode > target_season.total_episodes:
        raise ValueError(
            f"Episode {episode} exceeds season {season} "
            f"total episodes ({target_season.total_episodes})."
        )

    total_episodes = get_episodes_amount(seasons)
    seasons_before = [s for s in seasons if s.season_number < season]
    offset_episodes = get_episodes_amount(seasons_before) + (
        episode - 1
    )  # -1: episode is 1-based
    available_episodes = total_episodes - offset_episodes

    if limit != -1 and limit > available_episodes:
        raise ValueError(
            f"Limit {limit} exceeds available episodes ({available_episodes}) "
            f"from season {season}, episode {episode}."
        )

    no_offset = episode == 1 and season == season_numbers[0]
    no_limit = limit == -1

    if no_offset and no_limit:
        number_of_pages = ceil(total_episodes / per_page)
        for x in range(number_of_pages):
            page_number = x + 1
            loaded_episodes = per_page * x
            page_limit = min(per_page, total_episodes - loaded_episodes)
            params.append(
                RequestParams(
                    offset=0,
                    page=page_number,
                    per_page=per_page,
                    limit=page_limit,
                )
            )
    else:
        wanted_episodes = available_episodes if no_limit else limit

        offset_page = floor(offset_episodes / per_page)
        offset_in_page = offset_episodes % per_page

        loaded = 0

        if offset_in_page > 0:
            page_limit = min(per_page - offset_in_page, wanted_episodes)
            params.append(
                RequestParams(
                    offset=offset_in_page,
                    page=offset_page + 1,
                    per_page=per_page,
                    limit=page_limit,
                )
            )
            loaded += page_limit

        while loaded < wanted_episodes:
            remaining = wanted_episodes - loaded
            current_page = (
                offset_page
                + ceil((loaded + 1) / per_page)
                + (1 if offset_in_page > 0 else 0)
            )
            page_limit = min(per_page, remaining)
            params.append(
                RequestParams(
                    offset=0,
                    page=current_page,
                    per_page=per_page,
                    limit=page_limit,
                )
            )
            loaded += page_limit

        total_episodes = wanted_episodes

    return PaginationDetails(total_episodes=total_episodes, request_params=params)


def get_dub_or_raise(
    item_details: RootItemDetailsModel,
    language_name_or_code: str = DEFAULT_DUB_LANGUAGE_NAME_OR_CODE,
) -> DubModel:

    lan_names = []
    lan_codes = []

    # First pass: strict or fuzzy match requested language.
    for dub in item_details.dubs:
        if (
            dub.lan_name == language_name_or_code
            or dub.lan_code == language_name_or_code
            or language_matches(dub.lan_name, language_name_or_code)
            or language_matches(dub.lan_code, language_name_or_code)
        ):
            return dub

        lan_names.append(dub.lan_name)
        lan_codes.append(dub.lan_code)

    # If a French default was requested and no explicit French dub is exposed,
    # fall back to Original instead of accidentally selecting another dub such
    # as Hindi.
    if language_matches(language_name_or_code, "French"):
        for dub in item_details.dubs:
            if dub.original or language_matches(dub.lan_name, "Original"):
                return dub

    raise MissingDubError(
        f"No dub matched that language name or language code "
        f"{language_name_or_code!r}. Availables ones include - "
        f"language_names : {lan_names}, language_codes : {lan_codes}"
    )


_FRENCH_ALIASES = {
    "fr",
    "fra",
    "fre",
    "fr-fr",
    "français",
    "francais",
    "french",
    "vf",
    "vff",
    "version francaise",
    "version française",
}


def normalize_language_value(value: object) -> str:
    """Normalize language/dub labels coming from inconsistent API payloads."""
    if value is None:
        return ""
    normalized = str(value).strip().lower()
    normalized = normalized.replace("_", "-")
    normalized = re.sub(r"\s+dub\b", "", normalized).strip()
    normalized = re.sub(r"\bdub\s+", "", normalized).strip()
    return normalized


def language_matches(value: object, language_name_or_code: str) -> bool:
    """Fuzzy language matching for dubs/captions.

    It accepts common French values such as ``fr``, ``fra``, ``fre``,
    ``French``, ``Français`` and titles containing ``VF`` or
    ``version française``.
    """
    wanted = normalize_language_value(language_name_or_code)
    current = normalize_language_value(value)
    if not wanted or not current:
        return False
    if wanted == current or wanted in current or current in wanted:
        return True
    if wanted in _FRENCH_ALIASES:
        return any(alias in current for alias in _FRENCH_ALIASES)
    return False


def _iter_search_language_values(item: dict) -> list[object]:
    values: list[object] = []
    for key in ("dubs", "language", "subtitles", "title", "postTitle", "aka"):
        raw = item.get(key)
        if isinstance(raw, list):
            values.extend(raw)
        elif raw:
            values.append(raw)
    return values


def score_search_item(
    item: dict,
    query: str,
    preferred_language: str = DEFAULT_DUB_LANGUAGE_NAME_OR_CODE,
) -> int:
    """Score search results so localized/French variants appear first."""
    score = 0
    title = normalize_language_value(item.get("title", ""))
    q = normalize_language_value(query)

    if title == q:
        score += 100
    elif title.startswith(q):
        score += 40
    elif q and q in title:
        score += 15

    if item.get("hasResource") is True:
        score += 25

    release_date = str(item.get("releaseDate", ""))
    if q == "titanic" and release_date.startswith("1997"):
        score += 80

    for value in _iter_search_language_values(item):
        if language_matches(value, preferred_language):
            score += 60
        if language_matches(value, "French"):
            score += 20

    return score


def sort_search_items_for_preferred_language(
    items: list[dict],
    query: str,
    preferred_language: str = DEFAULT_DUB_LANGUAGE_NAME_OR_CODE,
) -> list[dict]:
    """Return search items ordered like the French app search surface."""
    return sorted(
        items,
        key=lambda item: score_search_item(item, query, preferred_language),
        reverse=True,
    )
